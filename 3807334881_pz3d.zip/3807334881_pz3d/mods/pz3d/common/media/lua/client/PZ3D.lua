require "TimedActions/ISReloadWeaponAction"
require "Hotbar/ISHotbar"
require "ISUI/ISUIElement"
require "ISUI/ISWorldObjectContextMenu"
require "TimedActions/ISTransferAction"
require "TimedActions/ISGrabItemAction"
require "ISUI/ISInventoryPage"

 
local nativeTransferItem = ISTransferAction.transferItem
local nativeDropOffset = ISTransferAction.GetDropItemOffset
function ISTransferAction.GetDropItemOffset(character, square, item)
    if PZ3D and PZ3D.dropMatches(character, item, square) then
        return PZ3D.dropX(), PZ3D.dropY(), PZ3D.dropZ()
    end
    return nativeDropOffset(character, square, item)
end
function ISTransferAction:transferItem(character, item, srcContainer, destContainer, dropSquare)
    if not PZ3D or not PZ3D.active() or PZ3D.nativeControls and PZ3D.nativeControls() or not dropSquare or destContainer:getType() ~= "floor"
        or not srcContainer:isInCharacterInventory(character) then
        return nativeTransferItem(self, character, item, srcContainer, destContainer, dropSquare)
    end
    local best, clearance = nil, -1
    for attempt=0,47 do
        local square=PZ3D.dropCandidate(character,item,attempt)
        if square and self:canDropOnFloor(square,character) and self:floorHasRoomFor(square,character,item,destContainer) then
            local space=PZ3D.dropClearance()
            if space>clearance then best=attempt; clearance=space end
            if space>=0.24 then break end
        end
    end
    if best then dropSquare=PZ3D.dropCandidate(character,item,best) else PZ3D.cancelDrop() end
    local ok, result=pcall(nativeTransferItem,self,character,item,srcContainer,destContainer,dropSquare)
    if ok then PZ3D.finishDrop(item) else PZ3D.cancelDrop(); error(result) end
    return result
end

LuaEventManager.AddEvent("OnPZ3DAction")
LuaEventManager.AddEvent("OnPZ3DMode")
LuaEventManager.AddEvent("OnPZ3DContainer")
LuaEventManager.AddEvent("OnPZ3DContext")
LuaEventManager.AddEvent("OnPZ3DPickup")
LuaEventManager.AddEvent("OnPZ3DMap")
LuaEventManager.AddEvent("OnPZ3DVehicleInput")
Events.OnPZ3DPickup.Add(function(player, object)
    if not PZ3D or not PZ3D.capture() or not object or not object:getSquare() then return end
    local queue=ISTimedActionQueue.getTimedActionQueue(player)
    if queue and #queue.queue>0 then return end
    local action=ISGrabItemAction:new(player,object,ISWorldObjectContextMenu.grabItemTime(player,object))
    if action:isValid() then ISTimedActionQueue.add(action) end
end)
Events.OnDeadBodySpawn.Add(function() if PZ3D and PZ3D.active() then PZ3D.corpseSpawned() end end)
local pendingShot, ownedReload, exitWatch
local function nativeTopDown() return PZ3D and PZ3D.nativeControls and PZ3D.nativeControls() end
local inventoryState, aimedContext, mapRequested
local mapHolding, mapRadialShown, nativeMapHandlers
local nativeVehicleInput=false
local function mapHandlers(custom)
    if not ISWorldMap then return end
    if custom and not nativeMapHandlers then
        Events.OnKeyStartPressed.Remove(ISWorldMap.onKeyStartPressed)
        Events.OnKeyKeepPressed.Remove(ISWorldMap.onKeyKeepPressed)
        Events.OnKeyPressed.Remove(ISWorldMap.onKeyReleased)
        nativeMapHandlers=true
    elseif not custom and nativeMapHandlers then
        Events.OnKeyStartPressed.Add(ISWorldMap.onKeyStartPressed)
        Events.OnKeyKeepPressed.Add(ISWorldMap.onKeyKeepPressed)
        Events.OnKeyPressed.Add(ISWorldMap.onKeyReleased)
        nativeMapHandlers=nil
    end
end
Events.OnPZ3DVehicleInput.Add(function(native)
    nativeVehicleInput=native and PZ3D.active()
    mapHandlers(PZ3D.active() and not nativeVehicleInput and not nativeTopDown())
end)
local function mapVisible()
    local p=getPlayer()
    local q=p and ISTimedActionQueue.getTimedActionQueue(p)
    return (ISWorldMap_instance and ISWorldMap_instance:isVisible()) or (q and q.queue[1] and q.queue[1].Type == "ISReadWorldMap")
end
local function mapGesture(kind)
    local key=getCore():getKey("Map")
    local radial=getPlayerRadialMenu(0)
    if kind == "press" then
        if not ISWorldMap or not ISWorldMap.checkKey(key) then return end
        mapHolding=true; mapRadialShown=false
        ISWorldMap.onKeyStartPressed(key)
    elseif kind == "hold" and mapHolding and not mapRadialShown then
        ISWorldMap.onKeyKeepPressed(key)
        if radial and radial:isReallyVisible() then mapRadialShown=true; PZ3D.mapUi(true) end
    elseif kind == "release" or kind == "cancel" then
        if kind == "release" and mapHolding then ISWorldMap.onKeyReleased(key) end
        if kind == "cancel" and radial then radial:removeFromUIManager() end
        mapHolding=false; mapRadialShown=false
        mapRequested=mapVisible() == true or (radial and radial:isReallyVisible()) or false
        PZ3D.mapUi(mapRequested)
    end
end
Events.OnPZ3DMap.Add(mapGesture)
local function closeAimedContext()
    if aimedContext then aimedContext:hideAndChildren(); aimedContext=nil end
end
local function closeContextMenus()
    closeAimedContext()
    local elements=UIManager and UIManager.getUI()
    if not elements then return end
    for i=elements:size()-1,0,-1 do
        local menu=elements:get(i):getTable()
        if menu and menu.hideAndChildren then menu:hideAndChildren() end
    end
end
local function inventoryPages(player, show)
    if not player or nativeTopDown() then return end
    local pages = {getPlayerInventory(player:getPlayerNum()), getPlayerLoot(player:getPlayerNum())}
    for _, page in ipairs(pages) do
        page:setVisible(show)
        if show then
            page:setPinned()
            page.isCollapsed = false
            page:clearMaxDrawHeight()
        end
    end
    if not show and ISMouseDrag then ISMouseDrag.dragging = nil end
end
local function saveInventory(player)
    inventoryState = {}
    for _, page in ipairs({getPlayerInventory(player:getPlayerNum()), getPlayerLoot(player:getPlayerNum())}) do
        inventoryState[#inventoryState+1] = {page=page, visible=page:getIsVisible(), pin=page.pin, collapsed=page.isCollapsed, counter=page.collapseCounter}
    end
end
local function restoreInventory()
    for _, saved in ipairs(inventoryState or {}) do
        local page = saved.page
         
         
        if saved.pin then page:setPinned() else page:collapse() end
        page.pin = saved.pin
        page.collapseButton:setVisible(saved.pin == true)
        page.pinButton:setVisible(saved.pin ~= true)
        page.isCollapsed = false
        if saved.collapsed then page:collapseNow() else page:clearMaxDrawHeight() end
        page.collapseCounter = saved.counter
        page:setVisible(saved.visible)
    end
    inventoryState = nil
end
 
 
local nativeSaveInventoryLayout = ISInventoryPage.SaveLayout
function ISInventoryPage:SaveLayout(name, layout)
    nativeSaveInventoryLayout(self, name, layout)
    for _, saved in ipairs(inventoryState or {}) do
        if saved.page == self then
            layout.pin = saved.pin and "true" or "false"
            layout.visible = saved.visible and "true" or "false"
            return
        end
    end
end
local function diagnosticsEnabled() return PZ3D and PZ3D.clientOption("diagnostics") end
local function describe(item)
    return item and (item:getFullType() .. "#" .. tostring(item:getID())) or "none"
end
local function slotLog(player, slot, queue)
    if not diagnosticsEnabled() then return end
    local bar = getPlayerHotbar(player:getPlayerNum())
    local attached = bar and bar.attachedItems and bar.attachedItems[slot]
    print("[pz3d] Hotbar request slot=" .. tostring(slot) .. " key=" .. tostring(getCore():getKey("Hotbar " .. slot)) ..
        " bar=" .. tostring(bar ~= nil) .. " allowed=" .. tostring(bar and bar:isAllowedToActivateSlot()) ..
        " slots=" .. tostring(bar and bar.availableSlot and #bar.availableSlot or 0) .. " attached=" .. describe(attached) ..
        " primary=" .. describe(player:getPrimaryHandItem()) .. " queue=" .. tostring(queue and #queue.queue or 0))
end
local function shoot(player, gun)
    if not gun:isRanged() then return PZ3D.meleeAttack() end
    return PZ3D.requestFire()
end

local function action(player, kind, slot)
    if not PZ3D or not PZ3D.capture() or not player or player:isDead() then return end
    local queue = ISTimedActionQueue.getTimedActionQueue(player)
    local gun = player:getPrimaryHandItem()
    if kind == "slot" then slotLog(player, slot, queue) end
    if queue and #queue.queue > 0 then
        local loading = queue.queue[1]
        if kind ~= "fire" or not gun or not instanceof(gun, "HandWeapon") or not gun:isRanged() or
            gun:getMagazineType() or not loading.reloading or loading.gun ~= gun then return end
        if not ISReloadWeaponAction.canShoot(player, gun) and gun:getCurrentAmmoCount() <= 0 then return end
         
        ISTimedActionQueue.clear(player)
        if not ISReloadWeaponAction.canShoot(player, gun) then
            ISReloadWeaponAction.OnPressRackButton(player, gun, false)
            ownedReload = {player=player, gun=gun}
            pendingShot = {player=player, gun=gun, untilTime=getTimestampMs()+5000}
            return
        end
    end
    if kind == "slot" then
        local bar = getPlayerHotbar(player:getPlayerNum())
        if bar and bar:isAllowedToActivateSlot() then bar:activateSlot(slot) end
        return
    end
    if not gun or not instanceof(gun, "HandWeapon") then return end
    if kind == "fire" then shoot(player, gun); return end
    if not gun:isRanged() then return end
    if kind == "reload" then
        ownedReload = {player=player, gun=gun}
        ISReloadWeaponAction.BeginAutomaticReload(player, gun)
    elseif kind == "rack" then
        ownedReload = {player=player, gun=gun}
        ISReloadWeaponAction.OnPressRackButton(player, gun, false)
    end
end
Events.OnPZ3DAction.Add(action)
 
 
Events.OnWeaponSwingHitPoint.Add(function(player, weapon)
    if PZ3D then PZ3D.combatSwing(player, weapon) end
end)
Events.OnWeaponHitXp.Add(function(player)
    if PZ3D then PZ3D.combatHit(player) end
end)
local function stateLog(player, label)
    if not diagnosticsEnabled() then return end
    local queue = ISTimedActionQueue.getTimedActionQueue(player)
    local first = queue and queue.queue[1]
    print("[pz3d] " .. label .. " state=" .. tostring(player:getCurrentState()) ..
        " blocked=" .. tostring(player:isBlockMovement()) .. " loading=" .. tostring(player:getVariableBoolean("isLoading")) ..
        " queue=" .. tostring(queue and #queue.queue or 0) .. " action=" .. tostring(first and first.Type) ..
        " primary=" .. describe(player:getPrimaryHandItem()))
end
local nativeEscapeHandler
Events.OnPZ3DMode.Add(function(player, kind)
    if nativeTopDown() and kind~="exit" then
        restoreInventory();mapHandlers(false)
        if nativeEscapeHandler then Events.OnKeyPressed.Add(nativeEscapeHandler);nativeEscapeHandler=nil end
        return
    end
    if kind=="perspective" then kind="enter" end
    if kind == "closeMap" then
        if ISWorldMap_instance and ISWorldMap_instance:isVisible() then ISWorldMap_instance:onKeyRelease(Keyboard.KEY_ESCAPE)
        else
            local q=ISTimedActionQueue.getTimedActionQueue(player)
            if q and q.queue[1] and q.queue[1].Type == "ISReadWorldMap" then ISTimedActionQueue.clear(player) end
        end
    elseif kind == "pause" then
        closeAimedContext()
        if ToggleEscapeMenu then ToggleEscapeMenu(getCore():getKey("Main Menu")) end
        if diagnosticsEnabled() then print("[pz3d] Escape menu visible=" .. tostring(MainScreen and MainScreen.instance and MainScreen.instance:isVisible()) .. " speed=" .. tostring(getGameSpeed and getGameSpeed())) end
    elseif kind == "resume" or kind == "ui" then
        if kind == "resume" then closeContextMenus() end
        inventoryPages(player, PZ3D.inventoryUi())
    elseif kind == "exit" then
        mapGesture("cancel")
        nativeVehicleInput=false;mapHandlers(false)
        if nativeEscapeHandler then Events.OnKeyPressed.Add(nativeEscapeHandler); nativeEscapeHandler=nil end
        if mapRequested and ISWorldMap_instance and ISWorldMap_instance:isVisible() then ISWorldMap.HideWorldMap(player:getPlayerNum()) end
        mapRequested=nil
        restoreInventory()
        pendingShot = nil
        stateLog(player, "Exit before action cleanup")
        local queue = ISTimedActionQueue.getTimedActionQueue(player)
        local first = queue and queue.queue[1]
        local firearmAction = first and (first.reloading or first.Type == "ISRackFirearm" or first.Type == "ISEjectMagazine" or first.Type == "ISInsertMagazine")
        if ownedReload and ownedReload.player == player and firearmAction and first.gun == ownedReload.gun then
             
            ISTimedActionQueue.clear(player)
            stateLog(player, "Exit stopped FPS reload/rack")
        end
        ownedReload = nil
        exitWatch = diagnosticsEnabled() and {player=player, untilTime=getTimestampMs()+3000, nextTime=getTimestampMs()+500} or nil
    elseif kind == "enter" then
        nativeVehicleInput=false;mapHandlers(true)
         
         
        if ToggleEscapeMenu and not nativeEscapeHandler then
            nativeEscapeHandler=ToggleEscapeMenu
            Events.OnKeyPressed.Remove(nativeEscapeHandler)
        end
        exitWatch = nil
        if not inventoryState then saveInventory(player) end
        inventoryPages(player, false)
    end
end)
Events.OnPZ3DContainer.Add(function(player, container)
    inventoryPages(player, true)
    local loot = getPlayerLoot(player:getPlayerNum())
    if not loot then return end
    loot:refreshBackpacks()
    for _, button in ipairs(loot.backpacks or {}) do
        if button.inventory == container then
            local object = container:getParent()
            if instanceof(object, "IsoThumpable") and object:isLockedToCharacter(player) then return end
             
             
            if not container:isExplored() then
                ItemPicker.fillContainer(container, player)
                container:setExplored(true)
            end
            loot.inventoryPane.selected = {}
            loot:setNewContainer(container)
            return
        end
    end
     
    if diagnosticsEnabled() then print("[pz3d] Aimed container is outside native loot access; inventory remains open") end
end)
Events.OnPZ3DContext.Add(function(player, object)
    closeAimedContext()
     
     
    local context = ISWorldObjectContextMenu.createMenu(player:getPlayerNum(), {object}, -10000, -10000, false)
    if not context or context == true then return end
    context:setX(getCore():getScreenWidth()/2)
    context:setY(getCore():getScreenHeight()/2)
    aimedContext=context
end)
local hadCharacterControl=false
Events.OnTick.Add(function()
    local controlsCharacter=PZ3D and not nativeTopDown() and PZ3D.capture() or false
    if controlsCharacter and not hadCharacterControl then closeContextMenus() end
    hadCharacterControl=controlsCharacter
    if PZ3D and PZ3D.active() and not (PZ3D.dead and PZ3D.dead()) then
        if nativeVehicleInput then PZ3D.mapUi(mapVisible() == true) end
        if mapRequested and not mapHolding then
            local p=getPlayer()
            local q=p and ISTimedActionQueue.getTimedActionQueue(p)
            local visible=ISWorldMap_instance and ISWorldMap_instance:isVisible()
            local reading=q and q.queue[1] and q.queue[1].Type == "ISReadWorldMap"
            local radial=getPlayerRadialMenu(0)
            if not visible and not reading and not (radial and radial:isReallyVisible()) then mapRequested=nil; PZ3D.mapUi(false) end
        end
        inventoryPages(getPlayer(), PZ3D.inventoryUi())
    end
    if exitWatch and getTimestampMs() >= exitWatch.nextTime then
        local watch = exitWatch
        if not watch.player:isDead() then stateLog(watch.player, "Native control follow-up") end
        watch.nextTime = getTimestampMs()+1000
        if getTimestampMs() >= watch.untilTime or watch.player:isDead() then exitWatch = nil end
    end
    if ownedReload then
        local q = ISTimedActionQueue.getTimedActionQueue(ownedReload.player)
        if not q or #q.queue == 0 then ownedReload = nil end
    end
    if not pendingShot then return end
    local p = pendingShot
    if not PZ3D or not PZ3D.capture() or p.player:isDead() or p.player:getPrimaryHandItem() ~= p.gun or getTimestampMs() > p.untilTime then
        pendingShot = nil; return
    end
    local queue = ISTimedActionQueue.getTimedActionQueue(p.player)
    if not queue or #queue.queue == 0 then pendingShot=nil; shoot(p.player, p.gun) end
end)

 
local painter
local reserve, reserveAt, reserveGun = 0, 0, nil
local function fit(tm, text, width)
    if tm:MeasureStringX(UIFont.Small, text) <= width then return text end
    local value = text
    while #value > 0 and tm:MeasureStringX(UIFont.Small, value .. "...") > width do
        local pos = #value
        while pos > 1 and string.byte(value, pos) >= 128 and string.byte(value, pos) < 192 do pos=pos-1 end
        value = string.sub(value, 1, pos-1)
    end
    return value .. "..."
end
local function drawWeapon(tm, player)
    local gun = player:getPrimaryHandItem()
    if not gun then return end
    local line = tm:getFontHeight(UIFont.Small)+4
    local big = tm:getFontHeight(UIFont.Massive)
    local x, width = 96, math.min(330, getCore():getScreenWidth()-120)
    local ranged = instanceof(gun, "HandWeapon") and gun:isRanged()
    local height = math.max(76, ranged and line*2+big+26 or line+36)
    local y = getCore():getScreenHeight()-height-88
    local iconWidth = math.min(82, width*.26)
    local textX = x+iconWidth+20
    local textWidth = width-iconWidth-36
    if not painter then
        painter = ISUIElement:new(0, 0, 1, 1)
        painter.wantMouseEvents = false
        painter:initialise(); painter:instantiate()
    end
    painter:setX(x); painter:setY(y); painter:setWidth(width); painter:setHeight(height)
    painter:drawRect(0, 0, width, height, 0.82, 0.035, 0.045, 0.055)
    painter:drawRect(0, 0, 3, height, 1, 0.55, 0.77, 0.82)
    local icon = gun:getTex()
    if icon then painter:drawTextureScaledAspect(icon, 12, 12, iconWidth-8, height-24, 1, 1, 1, 1) end
    tm:DrawString(UIFont.Small, textX, y+12, fit(tm, gun:getDisplayName(), textWidth), 0.92, 0.96, 1, 1)
    if not ranged then return end
    local now = getTimestampMs()
    if gun ~= reserveGun or now-reserveAt > 250 then
        reserve=PZ3D.reserveAmmo(); reserveAt=now; reserveGun=gun
    end
    local loaded = gun:getCurrentAmmoCount() + (gun:haveChamber() and gun:isRoundChambered() and 1 or 0)
    if player:isUnlimitedAmmo() then
         
         
        local cx, cy = textX-x+24, line+12+big*.48
        local px, py = cx, cy
        for i=1,64 do
            local t=i*math.pi/32
            local nx, ny = cx+24*math.sin(t), cy+10*math.sin(2*t)
            painter:drawLine(nil, px, py, nx, ny, 2, 1, 1, 1, 1)
            px, py=nx, ny
        end
    else
        tm:DrawString(UIFont.Massive, textX, y+line+12, tostring(loaded) .. " / " .. tostring(reserve), 1, 1, 1, 1)
    end
    local progress = gun:getJobDelta()
    local label = gun:isJammed() and getText("Tooltip_weapon_Jammed") or (progress > 0 and gun:getJobType() or "")
    if label and label ~= "" then
        tm:DrawString(UIFont.Small, textX, y+line+big+14, fit(tm, label, textWidth), 1, 0.76, 0.40, 1)
    end
    if progress > 0 then
        painter:drawRect(iconWidth+20, height-7, textWidth, 3, 0.8, 0.16, 0.23, 0.26)
        painter:drawRect(iconWidth+20, height-7, textWidth*progress, 3, 1, 0.60, 0.84, 0.85)
    end
end

local function draw()
    if PZ3D and PZ3D.authorSceneActive and PZ3D.authorSceneActive() then return end
    if not PZ3D or not PZ3D.active() or nativeTopDown() then return end
    if PZ3D.dead and PZ3D.dead() then return end
    if ISUIHandler and ISUIHandler.allUIVisible==false then return end
    local player = getPlayer()
    if not player then return end
    local tm = getTextManager()
    if not PZ3D or PZ3D.failed() then
        tm:DrawString(UIFont.Small, 96, 52, getText(PZ3D and "UI_PZ3D_Error" or "UI_PZ3D_Missing"), 1, 0.55, 0.3, 1)
        return
    end
    if PZ3D.active() then
        if PZ3D.cameraTuning() then
            tm:DrawString(UIFont.Small, 96, 42, getText("UI_PZ3D_Camera"), 0.85, 0.91, 1, 1)
            tm:DrawString(UIFont.Small, 96, 42+tm:getFontHeight(UIFont.Small)+4, PZ3D.cameraValues(), 1, 0.85, 0.55, 1)
        end
        if PZ3D.capture() then
            if not PZ3D.inVehicle() then drawWeapon(tm, player) end
        end
    end
end
Events.OnPostUIDraw.Add(draw)
