 
 
return {
    {
        id = "rising-vehicles",
        name = "Rising+Vehicles",
        sandboxPreset = "New Rising",
        spawnRegion = "Rosewood, KY",
        inventory = {
            {type="Base.Pistol3"},
            {type="Base.44Clip", fullAmmo=true},
            {type="Base.HuntingRifle", fullAmmo=true},
            {type="Base.AssaultRifle"},
            {type="Base.556Clip", fullAmmo=true},
            {type="Base.HandTorch"},
            {type="Base.WristWatch_Left_DigitalBlack", worn=true},
        },
    },
}
