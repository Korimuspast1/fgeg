require "ISUI/ISPanel"
require "ISUI/ISButton"
require "ISUI/ISTickBox"

PZ3DAuthorScene = ISPanel:derive("PZ3DAuthorScene")
local E = PZ3DAuthorScene
local colors={{1,.3,.25},{.3,1,.4},{.3,.6,1},{1,.8,.25},{.95,.95,.95}}
local function button(p,x,w,title,action)
    local b=ISButton:new(x,46,w,28,title,p,function(self) self:command(action) end)
    b:initialise();p:addChild(b);return b
end
local function toggle(p,x,w,title,action)
    local b=ISTickBox:new(x,88,w,26,"",p,function(self) if not self.syncing then self:command(action) end end)
    b:initialise();b:addOption(title);p:addChild(b);return b
end
function E:command(action)
    local ok,err=pcall(PZ3D.authorSceneCommand,action)
    self.error=ok and nil or tostring(err)
end
function E:restore()
    if self.restored then return end
    self.restored=true
    for element,visible in pairs(self.hidden) do element:setVisible(visible) end
    self:removeFromUIManager();E.instance=nil
    if self.owner then self.owner:setVisible(true);self.owner:refresh();self.owner:bringToTop() end
end
function E:hideGameUI()
    local elements=UIManager.getUI()
    for i=0,elements:size()-1 do
        local element=elements:get(i)
        if element~=self.javaObject and element:getTable()~=self then
            if self.hidden[element]==nil then self.hidden[element]=element:isVisible() end
            element:setVisible(false)
        end
    end
end
function E:prerender()
    if not PZ3D.authorSceneActive() then self:restore();return end
    self:hideGameUI()
    local w,h=getCore():getScreenWidth(),getCore():getScreenHeight()
    self:setWidth(w);self:setHeight(h)
    local ok,state=pcall(PZ3D.authorSceneMenu,w,h)
    if not ok then self.error=tostring(state);return end
    self.state=state
    self:drawRect(0,0,w,124,.97,.035,.045,.055)
    self:drawRect(0,h-76,w,76,.97,.035,.045,.055)
    self:drawText("Place model: "..state.name.." | PAUSED",16,12,1,1,1,1,UIFont.Medium)
    self:drawText("Left drag: orbit | Shift + left drag: pan | Wheel: zoom | Drag handles to edit the model",16,h-66,.85,.9,1,1,UIFont.Small)
    local info=self.error or (state.error~="" and state.error) or (state.saving and "Saving...") or "Drag a handle to adjust placement."
    self:drawText(info,16,h-39,1,.85,.6,1,UIFont.Small)
    self.syncing=true
    for key,tick in pairs(self.layers) do tick:setSelected(1,state[key]==true);tick.enable=not state.saving end
    self.syncing=false
    for _,b in ipairs(self.buttons) do b:setEnable(not state.saving) end
end
function E:render()
    if not self.state then return end
    local h=self.height
    self:setStencilRect(0,126,self.width,math.max(1,h-204))
    for _,line in ipairs(self.state.lines or {}) do
        local color=colors[line.color+1]
        self:drawLine(nil,line.x,line.y,line.endX,line.endY,3,1,color[1],color[2],color[3])
    end
    self:clearStencilRect()
    self:drawText("X",16,136,1,.3,.25,1,UIFont.Small)
    self:drawText("Y",38,136,.3,1,.4,1,UIFont.Small)
    self:drawText("Z",60,136,.3,.6,1,1,UIFont.Small)
    self:drawText(self.state.tool=="rotate" and "Axis rings | White ring: view rotation" or self.state.tool=="scale" and "Local axes / planes | Center: uniform scale" or "World axes / planes | Center: move in view plane",90,136,1,1,1,1,UIFont.Small)
end
function E:onMouseDown() return true end
function E:onMouseUp() return true end
function E:onMouseMove() return true end
function E:onRightMouseDown() return true end
function E:onRightMouseUp() return true end
function E:onMouseWheel(delta) PZ3D.authorSceneZoom(delta);return true end
function E.open(owner,row,object)
    PZ3D.authorSceneOpen(row.id,object)
    local p
    local ok,err=pcall(function()
    p=E:new(0,0,getCore():getScreenWidth(),getCore():getScreenHeight())
    p.owner=owner;p.hidden={};p.background=false;p.moveWithMouse=false;p:initialise()
    p.buttons={button(p,16,78,"Move","move"),button(p,102,78,"Rotate","rotate"),button(p,188,78,"Scale","scale"),button(p,282,88,"Focus","focus"),button(p,378,88,"Reset","reset")}
    table.insert(p.buttons,button(p,482,86,"Save","save"));table.insert(p.buttons,button(p,576,86,"Cancel","cancel"))
    p.layers={building=toggle(p,16,118,"Building","building"),furniture=toggle(p,146,118,"Furniture","furniture"),character=toggle(p,276,118,"Character","character"),cutaway=toggle(p,406,112,"X-ray","cutaway")}
    p.layers.building.tooltip="Show walls, roofs and upper floors. The floor under the model stays visible."
    p.layers.furniture.tooltip="Show surrounding furniture and loose items. The selected model stays visible."
    p.layers.character.tooltip="Show characters for scale comparison."
    p.layers.cutaway.tooltip="Clear a 90-degree horizontal sector through the full height of the scene."
    E.instance=p;p:addToUIManager();p:setAlwaysOnTop(true);p:hideGameUI()
    end)
    if not ok then PZ3D.authorSceneCommand("cancel");if p and p.hidden then p:restore() end;error(err) end
end
