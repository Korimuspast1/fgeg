require "DebugUIs/DebugMenu/ISDebugMenu"
require "ISUI/ISButton"
require "ISUI/ISTextEntryBox"

PZ3DCameraDebug=ISPanel:derive("PZ3DCameraDebug")
local Panel=PZ3DCameraDebug
local rows={
    {"cameraNear","Closest zoom"},{"cameraFar","Farthest zoom"},
    {"cameraNearSide","Shoulder offset / close"},{"cameraFarSide","Shoulder offset / far"},
    {"cameraNearUp","Height offset / close"},{"cameraFarUp","Height offset / far"},
    {"cameraPivotSide","Collision pivot / right"},{"cameraPivotForward","Collision pivot / forward"},
    {"cameraPivotUp","Collision pivot / up"},{"cameraRadius","Camera collision radius"},
    {"cameraWallGap","Wall safety gap"},{"cameraBodyClearance","Body safety distance"},
    {"cameraAimDistance","Hide tracers closer than"},
}
local function available() return PZ3D and PZ3D.cameraDebugAvailable and PZ3D.cameraDebugAvailable() end
function Panel:new(x,y,w,h)
    local o=ISPanel.new(self,x,y,w,h)
    o.backgroundColor={r=.06,g=.07,b=.08,a=.97};o.borderColor={r=.35,g=.4,b=.42,a=1}
    o.moveWithMouse=true;o.entries={};return o
end
function Panel:createChildren()
    ISPanel.createChildren(self)
    self.rh=getTextManager():getFontHeight(UIFont.Small)+10
    local r=self.rh
    for i,row in ipairs(rows) do
        local e=ISTextEntryBox:new("",340,12+(i+1)*r,100,r-4);e:initialise();self:addChild(e);self.entries[row[1]]=e
    end
    local y=12+(#rows+2)*r
    local function button(text,x,w,action)
        local b=ISButton:new(x,y,w,r,text,self,action);b:initialise();self:addChild(b)
    end
    button("Apply and save locally",12,220,function() self:apply() end)
    button("Reset defaults",240,140,function() PZ3D.cameraDebugReset();self:sync() end)
    button("Close",388,72,function() self:close() end)
    self.statusY=y+r+8;self:setHeight(self.statusY+2*r);self:sync()
end
function Panel:sync()
    local s=PZ3D.cameraDebugState()
    for _,row in ipairs(rows) do self.entries[row[1]]:setText(tostring(s[row[1]])) end
end
function Panel:apply()
    if not available() then return end
    local values={}
    for _,row in ipairs(rows) do
        local v=tonumber(self.entries[row[1]]:getText())
        if not v or v~=v or math.abs(v)>3000 then self.message="Enter centimetres between -3000 and 3000.";return end
        values[row[1]]=math.floor(v+.5)
    end
    if values.cameraNear<20 or values.cameraFar<=values.cameraNear then self.message="Zoom: closest >= 20 cm; farthest > closest.";return end
    for _,k in ipairs({"cameraRadius","cameraWallGap","cameraBodyClearance"}) do
        if values[k]<0 then self.message="Safety distances cannot be negative.";return end
    end
    if values.cameraAimDistance<50 then self.message="Tracer distance must be at least 50 cm.";return end
    for _,row in ipairs(rows) do PZ3D.cameraDebugSet(row[1],values[row[1]]) end
    self:sync();self.message="Applied and saved on this computer."
end
function Panel:prerender()
    ISPanel.prerender(self)
    self:drawText("pz3d | Camera",12,10,1,1,1,1,UIFont.Small)
    self:drawText("All values in cm. Positive shoulder = camera right.",12,12+self.rh,.8,.8,.8,1,UIFont.Small)
    for i,row in ipairs(rows) do self:drawText(row[2],12,12+(i+1)*self.rh,.85,.9,.9,1,UIFont.Small) end
    self:drawText(self.message or "Changes affect third-person camera; ADS stays unchanged.",12,self.statusY,.95,.8,.45,1,UIFont.Small)
    if available() then self:drawText(string.format("Current zoom: %.2f m",PZ3D.cameraDebugState().distance),12,self.statusY+self.rh,.8,.8,.8,1,UIFont.Small) end
end
function Panel:update() ISPanel.update(self);if not available() then self:close() end end
function Panel:close() self:removeFromUIManager();Panel.instance=nil end
function Panel.open()
    if not available() then return end
    if Panel.instance then Panel.instance:bringToTop();return end
    local p=Panel:new(math.max(0,getCore():getScreenWidth()-490),30,475,600)
    Panel.instance=p;p:initialise();p:addToUIManager();p:setAlwaysOnTop(true)
end
local original=ISDebugMenu.setupButtons
function ISDebugMenu:setupButtons()
    original(self)
    local info=self:addButtonInfo("pz3d | Camera",Panel.open,"MAIN")
    table.remove(self.buttons,#self.buttons)
    for i,b in ipairs(self.buttons) do if b.tab=="MAIN" and b.func==nil then table.insert(self.buttons,i,info);return end end
    table.insert(self.buttons,info)
end
