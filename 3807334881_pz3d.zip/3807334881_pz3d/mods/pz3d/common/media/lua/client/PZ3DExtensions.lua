require "ISUI/ISButton"
require "OptionScreens/MainScreen"
require "PZ3DModelCards"
local T=require "PZ3D/AssetsText"
local Layout=require "PZ3DMenuLayout"

 
local function installButton(screen)
    if not screen or screen.pz3dModels then return end
    local b=ISButton:new(0,18,200,28,T("pz3d Assets Manager"),nil,PZ3DModelCards.openPlay)
    b:initialise();b:setAnchorRight(true);b:setAnchorLeft(false);b:setVisible(false);screen:addChild(b);screen.pz3dModels=b
end
local nativeInstantiate=MainScreen.instantiate
function MainScreen:instantiate() nativeInstantiate(self);installButton(self) end
local nativeUpdate=MainScreen.update
function MainScreen:update()
    nativeUpdate(self)
    installButton(self)
    if self.pz3dModels then self.pz3dModels:setTitle(T("pz3d Assets Manager"));self.pz3dModels:setVisible(PZ3D and PZ3D.authorMenu and true or false) end
    Layout.update(self)
end
Events.OnGameBoot.Add(function() installButton(MainScreen.instance) end)
installButton(MainScreen.instance)
