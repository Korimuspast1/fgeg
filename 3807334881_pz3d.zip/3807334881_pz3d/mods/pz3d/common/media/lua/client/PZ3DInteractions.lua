require "TimedActions/ISContextualActions"
require "TimedActions/ISGrabCorpseAction"
require "RadioCom/ISRadioAction"
require "RadioCom/ISRadioWindow"
require "Entity/ISEntityUI"

 
 
 
PZ3DInteractions = {}
local I = PZ3DInteractions
local ownedPlayer, pendingUntil, sawAction
local function queue(player, action)
    ISTimedActionQueue.add(action)
end
local function tag(item, name) return item and item:hasTag(ItemTag[name]) end
local function goodSeed(item)
    if not instanceof(item,"Food") then return true end
    if item:isRotten() or item:isCooked() or item:isBurnt() then return false end
    if tag(item,"IS_CUTTING") and not item:isFresh() then return false end
    return math.abs(item:getHungerChange()) >= math.abs(item:getBaseHunger()) * (item:isFresh() and 1 or .75)
end
local function reachable(player, object)
    local sq = object and object:getSquare()
    return sq and player:getSquare() and math.abs(sq:getZ()-player:getZ()) < 1
        and sq:DistToProper(player:getSquare()) < 3
        and player:getSquare():canReachTo(sq)
end
local function takeMotion(player)
    ownedPlayer=player; pendingUntil=getTimestampMs()+750; sawAction=false
    player:setMoving(false); player:setRunning(false); player:setIsAiming(false)
    PZ3D.interactionAction(true)
end

function I.farming(player, object)
    local sq=object:getSquare()
    local floor=object==sq:getFloor()
    local item=player:getPrimaryHandItem()
    local plant=CFarmingSystem and CFarmingSystem.instance and CFarmingSystem.instance:getLuaObjectOnSquare(sq)
    if plant and not floor and plant:getIsoObject()~=object then plant=nil end
    if plant and plant:canHarvest() then
        return "ContextMenu_Harvest", function() queue(player,ISHarvestPlantAction:new(player,plant,100)) end
    end
    if not item or item:isBroken() then return end
    if instanceof(object,"IsoTree") and tag(item,"CHOP_TREE") then
        return "ContextMenu_Chop_Tree", function() queue(player,ISChopTreeAction:new(player,object)) end
    end
    if tag(item,"CUT_PLANT") and ISRemovePlantCursor:new(player,"bush"):getRemovableObject(sq)==object then
        return "ContextMenu_RemoveBush", function() queue(player,ISRemoveBush:new(player,sq,false)) end
    end
    if object==sq:getStump() and tag(item,"REMOVE_STUMP")
        or object==sq:getOre() and (tag(item,"PICK_AXE") or tag(item,"STONE_MAUL") or tag(item,"SLEDGEHAMMER") or tag(item,"CLUB_HAMMER")) then
        return "ContextMenu_Remove", function() queue(player,ISPickAxeGroundCoverItem:new(player,object)) end
    end
    if floor and tag(item,"DIG_PLOW") and ISFarmingMenu.canDigHereSquare(sq) then
        return "ContextMenu_Dig", function() queue(player,ISPlowAction:new(player,sq,item)) end
    end
    if plant and plant.state=="plow" and tag(item,"IS_SEED") and goodSeed(item) then
        local seeds={}
        for name,props in pairs(farming_vegetableconf.props) do
            table.insert(seeds,{name=name,props=props,text=getText("Farming_"..name)})
        end
        table.sort(seeds,function(a,b) return not string.sort(a.text,b.text) end)
        for _,entry in ipairs(seeds) do
            for _,seedType in ipairs(entry.props.seedTypes or {entry.props.seedName}) do
                if item:getFullType()==seedType then
                    local name=entry.name
                    return "ContextMenu_Sow_Seed",function()
                        local replacement=player:getInventory():getFirstTypeEvalRecurse(item:getFullType(),function(v) return v~=item and goodSeed(v) end)
                        queue(player,ISSeedActionNew:new(player,item,name,plant))
                        player:setPrimaryHandItem(nil)
                        if replacement then
                            ISInventoryPaneContextMenu.transferIfNeeded(player,replacement)
                            queue(player,ISEquipWeaponAction:new(player,replacement,20,true,false))
                        end
                    end
                end
            end
        end
    end
    if plant and plant.state=="plow" and tag(item,"DIG_PLOW") then
        return "ContextMenu_Remove",function() queue(player,ISShovelAction:new(player,item,plant,110)) end
    end
    if tag(item,"SCYTHE") and (floor or ISRemovePlantCursor:new(player,"grass"):getRemovableObject(sq)==object) then
        return "ContextMenu_RemoveGrass",function()
            local radius=(item:getType()=="HandScythe" or tag(item,"HAND_SCYTHE")) and 1 or 3
            queue(player,ISScything:new(player,item,sq,radius))
        end
    end
    if plant and plant.state=="seeded" and plant:isAlive() then
        if item:isWaterSource() and item:getCurrentUses()>0 and plant.waterLvl<100 then
            return "ContextMenu_Water",function()
                local prop=farming_vegetableconf.props[plant.typeOfSeed]
                local maximum=100
                if prop.waterLvlMax and prop.seasonRecipe and (player:isRecipeActuallyKnown(prop.seasonRecipe) or CFarmingSystem.instance:getXp(player)>=6) then maximum=prop.waterLvlMax end
                local uses=math.max(0,math.min(10,item:getCurrentUses(),math.ceil((maximum-plant.waterLvl)/10)))
                if uses>0 then queue(player,ISWaterPlantAction:new(player,item,uses,sq,20+6*uses)) end
            end
        end
        if tag(item,"FERTILIZER") or tag(item,"COMPOST") then
            return "ContextMenu_Fertilize",function()
                if item:getCurrentUses()>0 then queue(player,ISFertilizeAction:new(player,item,plant,100)) end
            end
        end
        local cures={GardeningSprayMilk="Mildew",GardeningSprayCigarettes="Flies",SlugRepellent="Slugs",GardeningSprayAphids="Aphids"}
        local cure=cures[item:getType()]
        if cure and item:getCurrentUses()>0 then
            return "ContextMenu_Treat_Problem",function() queue(player,ISCurePlantAction:new(player,item,1,plant,100,cure)) end
        end
    end
    if tag(item,"CLEAN_STAINS") then
        if floor and ISWorldObjectContextMenu.canCleanBlood(player,sq) then
            return "ContextMenu_CleanBlood",function() ISWorldObjectContextMenu.doCleanBlood(player,sq) end
        end
        local props=object:getProperties()
        if (floor or props and (props:has(IsoFlagType.collideN) or props:has(IsoFlagType.collideW))) and ISWorldObjectContextMenu.canCleanGraffiti(player,sq) then
            return "ContextMenu_CleanGraffiti",function() ISWorldObjectContextMenu.doCleanGraffiti(player,sq) end
        end
    end
end

function I.resolve(player, object)
    if not reachable(player,object) then return end
    if instanceof(object,"IsoWaveSignal") then
        local data=object:getDeviceData()
        if data and (data:getIsBatteryPowered() and data:getPower()>0 or data:canBePoweredHere()) then
            return data:getIsTurnedOn() and "ContextMenu_Turn_Off" or "ContextMenu_Turn_On",function()
                queue(player,ISRadioAction:new("ToggleOnOff",player,object))
            end
        end
        return
    end
    if instanceof(object,"IsoHutch") then
        return "ContextMenu_Hutch",function()
            if luautils.walkAdj(player,object:getSquare()) then queue(player,ISToggleHutchDoor:new(player,object:getHutch())) end
        end
    end
    if instanceof(object,"IsoButcherHook") then
        return
    end
    if instanceof(object,"IsoAnimal") then
        local item=player:getPrimaryHandItem()
        local buckets=player:getInventory():getAvailableFluidContainer(object:getData():getBreed():getMilkType())
        local milk=item and buckets and not buckets:isEmpty() and object:readyToBeMilked() and not player:hasFullInventory()
        local shear=tag(item,"SHEAR") and object:readyToBeSheared()
        local label=milk and "ContextMenu_Milk" or shear and "ContextMenu_Shear" or object:canBePet() and "ContextMenu_PetAnimal"
        if label then return label,function() player:triggerContextualAction("AnimalsInteraction",object) end end
        return
    end
    local props=object:getProperties()
    if props and props:has("BedType") then
        return "ContextMenu_Rest",function() player:triggerContextualAction("SleepInBed",object) end
    end
    if props and (props:has(IsoFlagType.climbSheetN) or props:has(IsoFlagType.climbSheetS)
        or props:has(IsoFlagType.climbSheetE) or props:has(IsoFlagType.climbSheetW)) then
        return "ContextMenu_Climb_Sheet_Rope",function()
            local sq=player:getCurrentSquare()
            if player:canClimbSheetRope(sq) then queue(player,ISClimbSheetRopeAction:new(player,false))
            elseif player:canClimbDownSheetRope(sq) then queue(player,ISClimbSheetRopeAction:new(player,true)) end
        end
    end
    return I.resolveTool(player,object)
end

function I.resolveTool(player,object)
    if not reachable(player,object) then return end
    local label,action=I.farming(player,object)
    if action then return label,function()
        if not ISFarmingMenu.walkToPlant(player,object:getSquare()) then return end
        player:setIsFarming(true)
        action()
    end end
end

function I.perform(player, object, held)
    if not PZ3D or not PZ3D.capture() or player:getVehicle() then return end
    local combat=PZ3D.combatInteraction()
    if combat then
        if PZ3D.sightsActive() or held or player:hasTimedActions() then return end
        local label,action=I.resolveTool(player,object)
        if action then takeMotion(player);action() end
        return
    end
    if player:isGrappling() then
        if held and reachable(player,object) then
            if instanceof(object,"IsoWindow") or instanceof(object,"IsoWindowFrame") or instanceof(object,"IsoThumpable") and object:isWindow() then
                takeMotion(player); player:throwGrappledTargetOutWindow(object); return
            end
            if object:getContainer() then
                takeMotion(player); player:throwGrappledIntoInventory(object:getContainer()); return
            end
            local props=object:getProperties()
            if props and (props:has(IsoFlagType.HoppableN) or props:has(IsoFlagType.HoppableW)) then
                local north=props:has(IsoFlagType.HoppableN)
                local dir=north and (player:getY()<object:getY() and IsoDirections.S or IsoDirections.N)
                    or (player:getX()<object:getX() and IsoDirections.E or IsoDirections.W)
                takeMotion(player); player:throwGrappledOverFence(object,dir:Rot180()); return
            end
        end
        player:setDoGrappleLetGo(); return
    end
    if not reachable(player,object) or player:hasTimedActions() then return end
    if held and instanceof(object,"IsoDeadBody") then
        if object:getStaticMovingObjectIndex()<0 then return end
        takeMotion(player)
        local primary,secondary=player:getPrimaryHandItem(),player:getSecondaryHandItem()
        if primary then queue(player,ISUnequipAction:new(player,primary,50)) end
        if secondary and secondary~=primary then queue(player,ISUnequipAction:new(player,secondary,50)) end
        queue(player,ISGrabCorpseAction:new(player,object))
        return
    end
    if held and instanceof(object,"IsoHutch") then
        return
    end
    local label,action=I.resolve(player,object)
    if action then
        takeMotion(player)
        action()
        local q=ISTimedActionQueue.getTimedActionQueue(player)
        if (not q or #q.queue==0) and not player:hasTimedActions() then
            ownedPlayer=nil;PZ3D.interactionAction(false)
        end
    end
end

LuaEventManager.AddEvent("OnPZ3DUseProbe")
LuaEventManager.AddEvent("OnPZ3DInteract")
Events.OnPZ3DUseProbe.Add(function(player,object)
    local label=I.resolve(player,object)
    PZ3D.nativeUseHint(label or "")
end)
Events.OnPZ3DInteract.Add(I.perform)
LuaEventManager.AddEvent("OnPZ3DPointer")
Events.OnPZ3DPointer.Add(function(player,object,container,fromCrosshair)
    if not PZ3D.active() or (PZ3D.capture() and not fromCrosshair) or not reachable(player,object) then return end
    if PZ3D.combatInteraction() then return end
    local function releasePointer()
        if fromCrosshair then PZ3D.openInteractionUi() end
    end
    if instanceof(object,"IsoButcherHook") then
        releasePointer()
        player:triggerContextualAction("OpenButcherHook",object)
        return
    end
    if instanceof(object,"IsoHutch") then
        releasePointer()
        if luautils.walkAdj(player,object:getSquare()) then queue(player,ISGetHutchInfo:new(player,object:getHutch())) end
        return
    end
    if instanceof(object,"IsoWaveSignal") then
        releasePointer()
        ISRadioWindow.activate(player,object)
        return
    end
    local config=object:getSpriteConfig()
    local master=config and config:getMultiSquareMaster() or object
    if reachable(player,master) and ISEntityUI.CanOpenWindowFor(player,master) then
        releasePointer()
        ISEntityUI.OpenWindow(player,master)
        return
    end
    if container then releasePointer();triggerEvent("OnPZ3DContainer",player,container) end
end)
 
 
LuaEventManager.AddEvent("OnPZ3DUiActions")
 
local observedContextManager
local observedContextClass
local function observeContextManager()
    if ISContextMenu and observedContextClass~=ISContextMenu then
        local hide=ISContextMenu.hideAndChildren
        ISContextMenu.hideAndChildren=function(self,...)
            if PZ3D and self.javaObject then PZ3D.pointerContextClosed(self.javaObject) end
            return hide(self,...)
        end
        observedContextClass=ISContextMenu
    end
    if not ISContextManager then return end
    local manager=ISContextManager.getInstance()
    if manager==observedContextManager then return end
    local create=manager.createWorldMenu
    manager.createWorldMenu=function(playerNum,object,objects,x,y,test)
        local context=create(playerNum,object,objects,x,y,test)
        if not test and PZ3D and PZ3D.active() and context and context~=true and context.javaObject then
            PZ3D.pointerContext(object,context.javaObject)
        end
        return context
    end
    observedContextManager=manager
end
Events.OnGameStart.Add(observeContextManager)
Events.OnPZ3DUiActions.Add(function(force)
    observeContextManager()
    if not PZ3D or not PZ3D.active() or PZ3D.nativeControls and PZ3D.nativeControls() or ownedPlayer then return end
    local player=getPlayer()
    if not player or player:getVehicle() then return end
    local actions=ISTimedActionQueue.getTimedActionQueue(player)
    if force or player:hasTimedActions() or actions and #actions.queue>0 then takeMotion(player) end
end)
Events.OnPZ3DMode.Add(function(player,kind) if kind=="exit" or kind=="perspective" then ownedPlayer=nil end end)
Events.OnTick.Add(function()
    if not ownedPlayer then return end
    if not PZ3D or not PZ3D.active() then ownedPlayer=nil;return end
    local player=ownedPlayer
    local actions=ISTimedActionQueue.getTimedActionQueue(player)
    local busy=actions and #actions.queue>0 or player:hasTimedActions()
        or player:isGrappling() or player:isClimbingRope()
        or player:isSittingOnFurniture() or player:isSitOnGround()
        or player:isGrappleThrowOutWindow() or player:isGrappleThrowOverFence() or player:isGrappleThrowIntoContainer()
        or PZ3D.interactionBodyTransition()
        or PZ3D.interactionTraversal and PZ3D.interactionTraversal()
    if busy then sawAction=true end
    if not busy and (sawAction or getTimestampMs()>=pendingUntil) then
        ownedPlayer=nil;PZ3D.interactionAction(false)
    end
end)
