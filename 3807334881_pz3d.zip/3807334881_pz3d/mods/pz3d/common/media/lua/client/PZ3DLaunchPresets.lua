 
if not getActivatedMods():contains("mod_studio") then return end
require "ModStudio/LaunchAPI"
local presets = require "PZ3D/LaunchPresets"
for _, preset in ipairs(presets) do
    ModStudio.Launch.register("pz3d", preset.id, preset)
end
