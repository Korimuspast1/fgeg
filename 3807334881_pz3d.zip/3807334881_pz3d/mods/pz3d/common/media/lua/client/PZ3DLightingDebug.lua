if not getDebug() then return end
require "ISUI/ISPanel"
require "ISUI/ISButton"
require "ISUI/ISTickBox"
require "DebugUIs/DebugMenu/ISDebugMenu"
PZ3DLightingDebug=ISPanel:derive("PZ3DLightingDebug")
local Panel=PZ3DLightingDebug
local function available() return PZ3D and PZ3D.lightingDebugAvailable and PZ3D.lightingDebugAvailable() end
function Panel:initialise()
    ISPanel.initialise(self);self.moveWithMouse=true
    self.backgroundColor={r=.055,g=.065,b=.075,a=.97};self.borderColor={r=.35,g=.4,b=.45,a=1}
end
function Panel:button(text,x,y,w,fn)
    local b=ISButton:new(x,y,w,self.rh,text,self,fn);b:initialise();self:addChild(b);return b
end
function Panel:createChildren()
    ISPanel.createChildren(self);self.rh=math.max(25,getTextManager():getFontHeight(UIFont.Small)+9)
    self:button("X",self.width-36,5,30,Panel.close)
    local y=2*self.rh
    self:button("Current",12,y,138,Panel.current)
    self:button("Native field",158,y,138,Panel.native)
    self:button("Hybrid detail",304,y,150,Panel.hybrid)
    self.options=ISTickBox:new(12,y+2*self.rh,self.width-24,self.rh-10,"",self,Panel.changed)
    self.options:initialise();self.options:instantiate();self:addChild(self.options)
    for _,name in ipairs({"Shape from native lamp directions","Sun / moon shape and 3D shadows","3D torch and shadows - hold beam tiles","Freeze base field - static comparison only"}) do self.options:addOption(name) end
    self:sync();self.statusY=y+7*self.rh
    self:button("Return to current",12,self.statusY+8*self.rh,200,Panel.current)
    self:button("Close",self.width-112,self.statusY+8*self.rh,100,Panel.close)
    self:setHeight(self.statusY+9*self.rh+12)
end
function Panel:sync()
    if not available() then return end
    local s=PZ3D.lightingState();self.syncing=true
    self.options:setSelected(1,s.shape);self.options:setSelected(2,s.sun);self.options:setSelected(3,s.torch);self.options:setSelected(4,s.freeze)
    self.syncing=false
end
function Panel:select(mode,defaults)
    local s=PZ3D.lightingState()
    PZ3D.lightingMode(mode,defaults or s.shape,defaults or s.sun,defaults or s.torch,s.freeze)
    self:sync()
end
function Panel:current() PZ3D.lightingReset();self:sync() end
function Panel:native() self:select("native",false) end
function Panel:hybrid() self:select("hybrid",true) end
function Panel:changed()
    if self.syncing or not available() then return end
    local s=PZ3D.lightingState()
    local shape,sun,torch=self.options:isSelected(1),self.options:isSelected(2),self.options:isSelected(3)
    local mode=s.mode
    if shape or sun or torch then mode="hybrid" elseif mode=="current" then mode="native" end
    PZ3D.lightingMode(mode,shape,sun,torch,self.options:isSelected(4));self:sync()
end
function Panel:prerender()
    ISPanel.prerender(self);self:drawText("pz3d | Lighting comparison",12,10,1,1,1,1,UIFont.Small)
    self:drawText("Session only. Current rendering is the default.",12,self.rh+8,.8,.8,.8,1,UIFont.Small)
    if not available() then return end
    local s=PZ3D.lightingState();local y=self.statusY
    local lines={"Requested: "..s.mode.." | Active: "..s.active..(s.ready and " | Ready" or " | Preparing..."),
        "Native samples: "..s.cells.." | Estimated: "..s.estimated.." | Held: "..s.held,
        string.format("Reader: %.2f ms | Field GPU: %.2f MiB",s.captureMs,s.gpuBytes/1048576),
        "Hidden native samples need estimates; detail is approximate.",
        "Torch detail keeps last clean RGB under native beam footprints.",
        "Switch lights with the torch off to refresh those samples.",
        "Missing samples use climate fill. Freeze stops live updates.",
        s.error~="" and s.error or "Close keeps this mode. Return to current restores normal light."}
    for i,line in ipairs(lines) do self:drawText(line,12,y+(i-1)*self.rh,.88,.88,.78,1,UIFont.Small) end
end
function Panel:update() ISPanel.update(self);if not available() then self:close() end end
function Panel:close() self:removeFromUIManager();Panel.instance=nil end
function Panel.open()
    if not available() then return end
    if Panel.instance then Panel.instance:bringToTop();return end
    local p=Panel:new(math.max(0,getCore():getScreenWidth()-595),30,580,590);Panel.instance=p;p:initialise();p:addToUIManager();p:setAlwaysOnTop(true)
end
local original=ISDebugMenu.setupButtons
function ISDebugMenu:setupButtons()
    original(self)
    local info=self:addButtonInfo("pz3d | Lighting comparison",Panel.open,"MAIN")
    table.remove(self.buttons,#self.buttons)
    for i,b in ipairs(self.buttons) do if b.tab=="MAIN" and b.func==nil then table.insert(self.buttons,i,info);return end end
    table.insert(self.buttons,info)
end
