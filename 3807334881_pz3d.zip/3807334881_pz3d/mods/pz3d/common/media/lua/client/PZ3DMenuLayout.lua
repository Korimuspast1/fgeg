PZ3DMenuLayout={}
function PZ3DMenuLayout.update(screen)
    local x=screen.width-20
    for _,name in ipairs({"pz3dModels","pz3dNews"}) do
        local b=screen[name]
        if b then
            local width=getTextManager():MeasureStringX(UIFont.Small,b.title)+32
            b:setWidth(width);x=x-width;b:setX(x);b:setY(18);x=x-6
        end
    end
end
return PZ3DMenuLayout
