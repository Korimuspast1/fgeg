require "ISUI/ISPanel"
require "ISUI/ISButton"
require "ISUI/ISComboBox"
require "ISUI/ISScrollingListBox"
require "ISUI/ISTextEntryBox"
require "ISUI/ISTickBox"
require "PZ3DAuthorScene"
local T=require "PZ3D/AssetsText"
PZ3DModelCards=ISPanel:derive("PZ3DModelCards")
local C=PZ3DModelCards
local function key(r) return r.mod.."|"..r.id..(r["local"] and "|local" or "|loaded") end
local function contains(items,value) for _,v in ipairs(items or {}) do if v==value then return true end end;return false end
local function button(p,x,y,w,title,fn) local b=ISButton:new(x,y,w,28,T(title),p,fn);b:initialise();p:addChild(b);return b end
local function fit(text,width)
    text=tostring(text or ""):gsub("[\r\n]"," ")
    while #text>0 and getTextManager():MeasureStringX(UIFont.Small,text)>width do local n=#text;while n>1 and text:byte(n)>=128 and text:byte(n)<192 do n=n-1 end;text=text:sub(1,n-1) end;return text
end
local function closePanel(p)
    for _,child in pairs(p.children or {}) do if child.isFocused and child:isFocused() then child:unfocus() end end
    p:setVisible(false);p:removeFromUIManager()
end
 
local function dialog(owner,title,fields,accept,options)
    options=options or {};local w,h=620,54
    for _,f in ipairs(fields) do f.y=h;h=h+(f.multi and 140 or f.tick and 64 or 88) end;h=h+78
    local p=ISPanel:new((getCore():getScreenWidth()-w)/2,(getCore():getScreenHeight()-h)/2,w,h)
    p:initialise();p.moveWithMouse=true;p.backgroundColor={r=.055,g=.065,b=.075,a=1};p.entries={};p.fieldErrors={}
    p.prerender=function(self)
        ISPanel.prerender(self);self:drawText(T(title),16,14,1,1,1,1,UIFont.Medium)
        for i,f in ipairs(fields) do
            if not f.tick then self:drawText(T(f.label),16,f.y,1,1,1,1,UIFont.Small) end
            if self.fieldErrors[i] then self:drawText(fit(self.fieldErrors[i],w-32),16,f.y+(f.multi and 114 or 56),1,.45,.4,1,UIFont.Small) end
        end
        if self.error then self:drawText(fit(self.error,w-32),16,h-70,1,.45,.4,1,UIFont.Small) end
    end
    for i,f in ipairs(fields) do
        local e
        if f.tick then e=ISTickBox:new(16,f.y+12,w-32,28,"",p,function() end);e:initialise();e:addOption(T(f.label));e:setSelected(1,f.value)
        else e=ISTextEntryBox:new(tostring(f.value or ""),16,f.y+28,w-32,f.multi and 80 or 24);e:initialise();e:instantiate();if f.multi then e:setMultipleLine(true) end;if f.readOnly then e:setEditable(false);e:setSelectable(true) end end
        p:addChild(e);p.entries[i]=e
    end
    local function done(self) closePanel(self);if owner then owner:refresh() end;if options.done then options.done() end end
    p.accept=button(p,16,h-40,140,options.title or (accept and "Save" or "Close"),function(self)
        if self.waiting then return end;self.error=nil;self.fieldErrors={};local values={};local valid=true
        for i,f in ipairs(fields) do
            if f.tick then values[i]=self.entries[i]:isSelected(1) else values[i]=self.entries[i]:getText() end
            if f.required and tostring(values[i]):match("^%s*$") then self.fieldErrors[i]=T("Enter a name");valid=false end
        end
        if not valid then return end
        local ok,err=pcall(function() if accept then accept(values) end end);if not ok then self.error=tostring(err);return end
        if options.async then self.waiting=true;self.accept:setEnable(false);self.cancel:setEnable(false) else done(self) end
    end)
    p.cancel=button(p,w-156,h-40,140,"Cancel",function(self) if not self.waiting then closePanel(self) end end);p.cancel:setVisible(accept~=nil)
    p.update=function(self)
        ISPanel.update(self)
        if self.waiting then local ok,state=pcall(PZ3D.authorMenu)
            if not ok then self.waiting=false;self.error=tostring(state)
            elseif not state.busy then self.waiting=false;if state.error~="" then self.error=state.error else done(self);return end end
        end
        self.accept:setEnable(not self.waiting and (not options.confirm or self.entries[options.confirm]:isSelected(1)));self.cancel:setEnable(not self.waiting)
    end
    if options.confirm then p.accept:setEnable(false) end;p:addToUIManager();p:setAlwaysOnTop(true);return p
end
function C:new(x,y,w,h) local o=ISPanel.new(self,x,y,w,h);o.moveWithMouse=true;o.backgroundColor={r=.055,g=.065,b=.075,a=.99};return o end
function C:run(fn) local ok,err=pcall(fn);self.error=not ok and tostring(err) or nil;self:refresh();self.actionPending=ok and self.state.busy end
local function list(p,x,y,w,h,draw,select)
    local l=ISScrollingListBox:new(x,y,w,h);l:initialise();l:setFont(UIFont.Small,6);l.itemheight=56;l.owner=p;l.doDrawItem=draw;l:setOnMouseDownFunction(p,select);p:addChild(l);return l
end
function C:initialise()
    ISPanel.initialise(self);self.view=self.view or "packs"
    self.browse=button(self,16,48,150,"Asset packs",function(p) p:setView("packs") end)
    self.targets=button(self,174,48,150,"Replacements",function(p) p:setView("targets") end)
    self.work=button(self,332,48,160,"Creative mode",function(p) p:setView("author") end)
    self.tools=button(self,self.width-216,12,200,"Creative mode: Off",C.toggleTools)
    self.settings=button(self,self.width-144,48,128,"Settings",function(p) p.configuring=not p.configuring;p:refresh() end)
    self.search=ISTextEntryBox:new("",16,88,self.width-70,26);self.search:initialise();self.search:instantiate();self.search:setPlaceholderText(T("Search assets, authors or tiles"));self:addChild(self.search)
    self.clearSearch=button(self,self.width-46,88,30,"X",function(p) p.search:setText("");p:refresh() end);self.clearSearch.tooltip=T("Clear search")
    self.groupWidth=math.floor(self.width*.19);self.cardWidth=math.floor(self.width*.23);self.cardX=self.groupWidth+28;self.previewX=self.cardX+self.cardWidth+12;self.galleryX=self.width-164;self.previewWidth=self.galleryX-self.previewX-12
    self.groups=list(self,16,144,self.groupWidth,self.height-244,C.drawGroup,C.selectGroup)
    self.list=list(self,self.cardX,144,self.cardWidth,self.height-244,C.drawRow,C.selectRow)
    self.gallery=list(self,self.galleryX,144,148,self.height-244,C.drawFile,C.selectFile);self.gallery.itemheight=126
    self.hero=ISPanel:new(self.previewX,144,self.previewWidth,self.height-244);self.hero:initialise();self.hero.owner=self;self.hero.moveWithMouse=false;self.hero.backgroundColor={r=.03,g=.04,b=.05,a=1};self:addChild(self.hero)
    self.hero.onMouseDown=function(h) h.dragging=true;return true end
    self.hero.onMouseUp=function(h) h.dragging=false;return true end;self.hero.onMouseUpOutside=self.hero.onMouseUp
    self.hero.onMouseMove=function(h,dx,dy) if h.dragging then local p=h.owner;p.yaw=(p.yaw or -45)-dx*.6;p.pitch=math.max(-89,math.min(89,(p.pitch or 25)+dy*.6)) end;return true end
    self.hero.onMouseMoveOutside=self.hero.onMouseMove
    self.hero.onMouseWheel=function(h,delta) h.owner.zoom=math.max(.25,math.min(4,(h.owner.zoom or 1)*(delta>0 and .9 or 1.1)));return true end
    self.hero.render=function(h)
        local p=h.owner;local info=p:livePreview(true)
        if info and info.texture then local size=math.min(h.width-12,h.height-36);h:drawTextureScaled(info.texture,(h.width-size)/2,(h.height-size-24)/2,size,size,1,1,1,1)
        else h:drawText(fit(info and (info.missing and T("File missing") or info.error~="" and info.error or T("Loading preview...")) or T("Select an asset"),h.width-24),12,h.height/2,.9,.8,.7,1,UIFont.Small) end
        if p.file then h:drawText(fit(p.file,h.width-20),10,h.height-25,.8,.85,.9,1,UIFont.Small) end
    end
    self.primary=button(self,16,self.height-82,140,"Use this asset",C.choose);self.auto=button(self,164,self.height-82,130,"Use default",C.automatic)
    self.disable=button(self,302,self.height-82,140,"Disable replacement",C.disableSelected)
    self.copyButton=button(self,302,self.height-82,150,"Add to my pack",C.copy);self.blend=button(self,460,self.height-82,140,"Open Blender",C.blender)
    self.more=button(self,608,self.height-82,128,"Asset details",C.modelDetails);self.remove=button(self,744,self.height-82,108,"Remove...",C.removeModel)
    self.closeButton=button(self,self.width-122,self.height-40,106,"Close",C.close)
    self.profileButton=button(self,32,194,360,"Set up profile",C.profile)
    self.projects=ISComboBox:new(32,288,480,28,self,C.selectProject);self.projects:initialise();self:addChild(self.projects)
    self.newPack=button(self,524,288,160,"New asset pack",C.createMod);self.packActions=button(self,696,288,160,"Pack details",C.packDetails)
    self.enable=button(self,32,360,220,"Enable creative mode",C.toggleTools)
    self:refresh();if not self.state.busy then self:run(PZ3D.authorProjects) end
end
function C:setView(view) self.view=view=="play" and "packs" or view;self.configuring=false;self.row=nil;self.file=nil;self.error=nil;self:refresh() end
function C:toggleTools()
    if self.state.authorMode then self:run(function() PZ3D.authorMode(false) end);return end;self.view="author"
    if self.state.profile~="" and self.state.workingId~="" then self:run(function() PZ3D.authorMode(true) end) else self:controls() end
end
function C:selectProject(combo) if not self.syncing then local i=self.projectIndices[combo.selected];if i then self:run(function() PZ3D.authorSelectProject(i) end) end end end
function C:createMod()
    dialog(self,"New asset pack",{{label="Pack name",required=true},{label="Description (optional)",multi=true},{label="Pack URL (optional)"}},function(v) PZ3D.authorCreateProject(v[1],v[2],v[3]) end,{async=true})
end
function C:profile()
    dialog(self,"Creative profile",{{label="Name",value=self.state.profile,required=true},{label="Contact (optional, any text)",value=self.state.profileUrl},{label="Allow repacking my new assets",tick=true,value=self.state.profileAllowRepack}},function(v) PZ3D.authorProfile(v[1],v[2],v[3]) end,{async=true})
end
function C:packDetails()
    dialog(self,"Asset pack details",{{label="Pack name",value=self.state.working,required=true},{label="Description (optional)",value=self.state.packDescription,multi=true},{label="Pack URL (optional)",value=self.state.packUrl}},function(v) PZ3D.authorPackDetails(v[1],v[2],v[3]) end,{async=true})
end
function C:selectGroup(g) if self.view=="targets" then self.source=g.source else self.pack=g.key end;self.row=nil;self.file=nil;self.error=nil;self:refresh() end
function C:selectRow(row)
    local changed=not self.row or key(self.row)~=key(row);self.row=row;self.error=nil
    if changed then self.file=nil;self.yaw=-45;self.pitch=25;self.zoom=1;self:syncFiles() end;self:controls()
end
function C:syncFiles()
    local scroll=self.gallery:getYScroll();self.gallery:clear();local found=false
    for _,file in ipairs(self.row and self.row.files or {}) do self.gallery:addItem(file,file);if file==self.file then found=true;self.gallery.selected=#self.gallery.items end end
    if not found then self.file=self.row and self.row.files and self.row.files[1] or nil;self.gallery.selected=1 end;self.gallery:setYScroll(scroll)
end
function C:selectFile(file) if self.file~=file then self.file=file;self.yaw=-45;self.pitch=25;self.zoom=1 end end
function C:preview(file)
    if not self.row or not file then return nil end;local r=self.row;local ok,result=pcall(PZ3D.assetThumbnail,r.mod,r.id,r["local"],file);return ok and result or {error=tostring(result)}
end
function C:livePreview(draw)
    if not self.row or not self.file then return nil end;local r=self.row;local ok,result=pcall(PZ3D.assetPreview,r.mod,r.id,r["local"],self.file,self.yaw or -45,self.pitch or 25,self.zoom or 1,draw==true);return ok and result or {error=tostring(result)}
end
function C:choose() local r=self.row;if r then self:run(function() PZ3D.assetChoose(r.mod,r.id,r["local"],self.view=="targets" and self.source or "") end) end end
function C:disableSelected() local r=self.row;if r then self:run(function() PZ3D.assetDisable(r.mod,r.id,r["local"],self.view=="targets" and self.source or "") end) end end
function C:automatic() if self.source then self:run(function() PZ3D.assetDefault(self.source) end) end end
function C:blender() if self.row then self:run(function() PZ3D.authorBlender(self.row.id) end) end end
function C:copy()
    local r=self.row;if not r then return end;if not self.state.creativeReady then self.pendingCopy=r;self:setView("author");return end
    self:run(function() PZ3D.authorCopy({{mod=r.mod,id=r.id,["local"]=r["local"]}}) end)
end
function C:createSelected()
    if not self.object then return end;if not self.state.creativeReady then self.pendingCreate=self.object;self:setView("author");return end
    self.pendingCreate=nil;self.view="author";self:run(function() PZ3D.authorCreate(self.object,self.state.profileAllowRepack) end);self.followFocus=true
end
function C:modelDetails()
    local r=self.row;if not r then return end;local editable=r.working and self.state.creativeReady
    dialog(self,"Asset details",{{label="Name",value=r.name,required=true,readOnly=not editable},{label="Description (optional)",value=r.description,multi=true,readOnly=not editable},{label="Author",value=r.author,readOnly=true},{label="Contact",value=r.url,readOnly=true}},editable and function(v) PZ3D.authorMetadata(r.id,v[1],v[2]) end or nil,{async=editable})
end
function C:removeModel()
    local r=self.row;if not r or not r.working then return end
    dialog(self,"Remove asset",{{label="Asset",value=r.name,readOnly=true},{label="Yes, I'm sure",tick=true,value=false}},function() PZ3D.authorRemove(r.id) end,{async=true,title="Remove",confirm=2})
end
function C:controls()
    local s=self.state;if not s then return end;local setup=self.view=="author" and (not s.creativeReady or self.configuring==true);self.setup=setup
    local idle=not s.busy;local r=self.row;local creative=s.creativeReady;local working=r and r.working and creative
    local selected={r=.12,g=.25,b=.35,a=1};local normal={r=.04,g=.05,b=.06,a=1}
    self.browse.backgroundColor=self.view=="packs" and selected or normal;self.targets.backgroundColor=self.view=="targets" and selected or normal;self.work.backgroundColor=self.view=="author" and selected or normal
    self.tools:setTitle(T(s.authorMode and "Creative mode: On" or "Creative mode: Off"));self.tools:setEnable(idle)
    self.tools:setWidth(getTextManager():MeasureStringX(UIFont.Small,self.tools.title)+28);self.tools:setX(self.width-self.tools.width-16)
    self.settings:setVisible(self.view=="author" and s.profile~="");self.settings:setEnable(idle);self.settings:setTitle(T(self.configuring and s.creativeReady and "Back to assets" or "Settings"));self.settings:setWidth(getTextManager():MeasureStringX(UIFont.Small,self.settings.title)+28);self.settings:setX(self.width-self.settings.width-16)
    for _,w in ipairs({self.search,self.clearSearch,self.groups,self.list,self.gallery,self.hero,self.primary,self.auto,self.disable,self.copyButton,self.blend,self.more,self.remove}) do w:setVisible(not setup) end
    self.groups:setVisible(not setup and self.view~="author");self.list:setX(self.view=="author" and 16 or self.cardX);self.list:setWidth(self.view=="author" and self.previewX-28 or self.cardWidth)
    self.primary:setEnable(idle and r~=nil and (not r["local"] or working) or false);self.auto:setVisible(not setup and self.view=="targets");self.auto:setEnable(idle and self.source~=nil)
    self.clearSearch:setEnable(self.search:getText()~="");self.disable:setEnable(idle and r~=nil and #(r.sources or {})>0)
    self.copyButton:setVisible(not setup and creative and r~=nil and not r.working);self.copyButton:setEnable(idle and r~=nil and r.allowRepack and not r.inWorking or false)
    self.copyButton:setTitle(T(r and r.inWorking and "In my pack" or "Add to my pack"))
    self.copyButton.tooltip=r and not r.allowRepack and T(r.repackReason or "The author does not allow repacking") or nil
    self.blend:setVisible(not setup and working or false);self.blend:setEnable(idle);self.more:setEnable(idle and r~=nil);self.remove:setVisible(not setup and working or false);self.remove:setEnable(idle)
    self.profileButton:setVisible(setup);self.profileButton:setTitle(T(s.profile=="" and "Set up profile" or "Edit profile")..(s.profile~="" and ": "..fit(s.profile,180) or ""));self.profileButton:setEnable(idle)
    local hasProfile=s.profile~="";self.projects:setVisible(setup and hasProfile);self.projects:setEnabled(idle);self.newPack:setVisible(setup and hasProfile);self.newPack:setEnable(idle)
    self.packActions:setVisible(setup and hasProfile and s.workingId~="");self.packActions:setEnable(idle);self.enable:setVisible(setup and hasProfile and s.workingId~="" and not s.authorMode);self.enable:setEnable(idle)
    local x=16;for _,b in ipairs({self.browse,self.targets,self.work}) do b:setX(x);b:setWidth(getTextManager():MeasureStringX(UIFont.Small,b.title)+28);x=x+b.width+8 end
    x=16;for _,b in ipairs({self.primary,self.auto,self.disable,self.copyButton,self.blend,self.more,self.remove}) do if b:isVisible() then b:setX(x);b:setWidth(getTextManager():MeasureStringX(UIFont.Small,b.title)+24);x=x+b.width+8 end end
end
function C:refresh(pollOnly)
    local ok,s=pcall(PZ3D.authorMenu);if not ok then self.error=tostring(s);return end;self.state=s
    if self.actionPending and not s.busy then self.actionPending=false;if s.error~="" then self.error=s.error;self.followFocus=false end end
    local focus=self.followFocus and not s.busy and s.focusId~=""
    if focus then self.view="author";self.configuring=false;self.search:setText("");self.followFocus=false end
    local query=string.lower(self.search:getText() or "")
    local group=self.view=="targets" and self.source or self.pack
    if pollOnly and not focus and not self.pendingCreate and not self.pendingCopy and self.displayCards==s.cards and self.displayView==self.view and self.displayGroup==group and self.displayQuery==query and self.displayWorking==s.workingId and self.displayProjectCount==#s.projects then self:controls();return end
    local picked=self.row and key(self.row);local scroll=self.list:getYScroll();local gs=self.groups:getYScroll();self.groups:clear();self.list:clear();self.row=nil
    local groups=self.view=="targets" and s.targets or s.packs;local selectedGroup=group;local valid=false;local matching={}
    if query~="" then for _,r in ipairs(s.cards) do
        if string.find(string.lower(r.name.." "..r.author.." "..table.concat(r.tiles or {}," ")),query,1,true) then
            matching[r.pack]=true;for _,source in ipairs(r.sources or {}) do matching[source]=true end
        end
    end end
    for _,g in ipairs(groups or {}) do
        local matches=query=="" or matching[g.source or g.key] or string.find(string.lower(g.name.." "..(g.tile or "")),query,1,true)
        if matches then self.groups:addItem(g.name,g);if (g.source or g.key)==selectedGroup then valid=true;self.groups.selected=#self.groups.items end end
    end
    if not valid then local first=self.groups.items[1];selectedGroup=first and (first.item.source or first.item.key);self.groups.selected=1 end
    if self.view=="targets" then self.source=selectedGroup else self.pack=selectedGroup end
    for _,r in ipairs(s.cards) do
        local visible=self.view=="author" and r.working or self.view=="targets" and contains(r.sources,self.source) or self.view=="packs" and r.pack==self.pack
        if visible and (query=="" or string.find(string.lower(r.name.." "..r.author.." "..table.concat(r.tiles or {}," ")),query,1,true) or self.view=="targets") then self.list:addItem(r.name,r);if key(r)==picked or focus and r.working and r.id==s.focusId then self.row=r;self.list.selected=#self.list.items end end
    end
    if not self.row and #self.list.items>0 then self.row=self.list.items[1].item;self.list.selected=1 end
    if not self.row or key(self.row)~=picked then self.file=nil;self.yaw=-45;self.pitch=25;self.zoom=1 end
    self.lastFocus=s.focusId;self.list:setYScroll(scroll);self.groups:setYScroll(gs);self:syncFiles()
    if self.displayGroup~=selectedGroup then self.groups:ensureVisible(self.groups.selected);self.list:setYScroll(0) end
    if focus then self.list:ensureVisible(self.list.selected) end
    self.displayCards=s.cards;self.displayView=self.view;self.displayGroup=selectedGroup;self.displayQuery=query;self.displayWorking=s.workingId;self.displayProjectCount=#s.projects
    if not self.projects.expanded then self.syncing=true;self.projects:clear();self.projectIndices={}
        if s.workingId=="" then self.projects:addOption(T("Select a working asset pack")) end
        for i,p in ipairs(s.projects) do self.projects:addOption(p.title);self.projectIndices[#self.projects.options]=i;if p.id==s.workingId then self.projects.selected=#self.projects.options end end;self.syncing=false
    end
    self:controls()
    if not s.busy and s.creativeReady then if self.pendingCreate then self.object=self.pendingCreate;self.pendingCreate=nil;self:createSelected() elseif self.pendingCopy then local row=self.pendingCopy;self.pendingCopy=nil;self.row=row;self:copy() end end
end
function C:prerender()
    ISPanel.prerender(self);if not self.nextRefresh or getTimestampMs()>=self.nextRefresh then self.nextRefresh=getTimestampMs()+500;self:refresh(true) end
    local s=self.state;if not s then return end;self:drawText(T("pz3d Assets Manager"),16,12,1,1,1,1,UIFont.Medium)
    if self.setup then self:drawText(T("Creative profile"),32,154,1,1,1,1,UIFont.Medium);if s.profile~="" then self:drawText(T("Working asset pack"),32,254,1,1,1,1,UIFont.Medium) end;self:drawText(T("Create assets from an object's context menu in the game."),32,424,.8,.85,.9,1,UIFont.Small)
    else
        self:drawText(T(self.view=="targets" and "Tiles and layers" or self.view=="author" and "My assets" or "Asset packs"),16,122,.8,.85,.9,1,UIFont.Small)
        if self.view~="author" then self:drawText(T(self.view=="targets" and "Available alternatives" or "Assets"),self.cardX,122,.8,.85,.9,1,UIFont.Small) end
        self:drawText(T("Model files"),self.galleryX,122,.8,.85,.9,1,UIFont.Small)
        if #self.list.items==0 then local group=self.groups.items[self.groups.selected];local loading=group and group.item.loading;self:drawText(fit(T(loading and "Loading..." or self.view=="author" and "Right-click an object in the game to create an asset." or "No assets found"),self.list.width-16),self.list.x+8,162,.75,.8,.85,1,UIFont.Small) end
    end
    if self.error then self:drawText(fit(self.error,self.width-164),16,self.height-34,1,.45,.4,1,UIFont.Small) elseif s.busy then self:drawText(T("Working..."),16,self.height-34,.8,.85,.9,1,UIFont.Small) end
end
function C.drawGroup(l,y,item)
    if y+l:getYScroll()+56<0 or y+l:getYScroll()>l.height then return y+56 end;if (item.itemindex or item.index)==l.selected then l:drawRect(0,y,l.width,56,.45,.25,.4,.55) end
    local g=item.item;l:drawText(fit(g.tile or g.name,l.width-20),8,y+4,1,1,1,1,UIFont.Small)
    local detail=g.tile and (g.layer..(g.state~="*" and " | "..g.state or "")) or (g.loading and T("Loading...") or tostring(g.count).." "..T("assets"))..(g["local"] and " | "..T("Local") or "")
    l:drawText(fit(detail,l.width-20),8,y+29,.65,.75,.85,1,UIFont.Small);return y+56
end
function C.drawRow(l,y,item)
    if y+l:getYScroll()+56<0 or y+l:getYScroll()>l.height then return y+56 end;if (item.itemindex or item.index)==l.selected then l:drawRect(0,y,l.width,56,.4,.3,.5,.7) end
    local r=item.item;local active=l.owner.view=="targets" and contains(r.selectedSources,l.owner.source) or l.owner.view~="targets" and r.selected
    local disabled=l.owner.view=="targets" and contains(r.disabledSources,l.owner.source) or l.owner.view~="targets" and r.disabled
    local badge=disabled and T("Disabled") or active and T("Selected") or "";local badgeWidth=badge~="" and getTextManager():MeasureStringX(UIFont.Small,badge)+12 or 0
    l:drawText(fit(r.name,l.width-20-badgeWidth),8,y+4,1,1,1,1,UIFont.Small)
    if badge~="" then l:drawText(badge,l.width-badgeWidth,y+4,.5,.85,.65,1,UIFont.Small) end
    local detail=(r.own and T("Mine") or r.author~="" and r.author or r.packTitle)..(not r.allowRepack and " | "..T("No repacking") or "")
    l:drawText(fit(detail,l.width-20),8,y+29,.7,.8,.9,1,UIFont.Small);return y+56
end
function C.drawFile(l,y,item)
    if y+l:getYScroll()+126<0 or y+l:getYScroll()>l.height then return y+126 end;if item.item==l.owner.file then l:drawRect(0,y,l.width,126,.4,.3,.5,.7) end
    local p=l.owner:preview(item.item);if p and p.texture then l:drawTextureScaled(p.texture,22,y+2,100,100,1,1,1,1)
    else l:drawText(T(p and p.missing and "File missing" or p and p.error~="" and "Cannot load file" or "Loading..."),8,y+40,.9,.75,.65,1,UIFont.Small) end
    l:drawText(fit(item.item,l.width-20),8,y+104,.8,.85,.9,1,UIFont.Small);return y+126
end
function C:close()
    if self.state and self.state.editing then return end;if self.projects.expanded then self.projects:hidePopup() end
    self.pendingCreate=nil;self.pendingCopy=nil;closePanel(self);PZ3D.authorPreviewClear();C.instance=nil
    if self.previousUi~=nil then PZ3D.assetManagerUi(self.previousUi)
    elseif self.previousSpeed~=nil and getPlayer() and getGameSpeed()==0 then setGameSpeed(self.previousSpeed) end
end
function C.open(object,view)
    if not PZ3D or not PZ3D.authorMenu then return end;view=view=="play" and "packs" or view
    if C.instance then local p=C.instance;p.object=object;if view then p.view=view end;p:refresh();p:bringToTop();return end
    local w,h=math.min(1360,getCore():getScreenWidth()-32),math.min(840,getCore():getScreenHeight()-32)
    local p=C:new((getCore():getScreenWidth()-w)/2,(getCore():getScreenHeight()-h)/2,w,h);p.object=object;p.view=view or "packs";C.instance=p;p:initialise();p:addToUIManager();p:setAlwaysOnTop(true)
    if getPlayer() then
        if PZ3D.active() and not PZ3D.nativeControls() then p.previousUi=PZ3D.assetManagerUi(true)
        else p.previousSpeed=getGameSpeed();setGameSpeed(0) end
    end
end
function C.openWorking() C.open(nil,"author") end
function C.openPlay() C.open(nil,"packs") end
local function context(player,menu,objects,test)
    if test or not PZ3D or not PZ3D.authorInspect or not PZ3D.authorEnabled() then return end
    local object,info;for _,candidate in ipairs(objects) do local ok,result=pcall(PZ3D.authorInspect,candidate);if ok and result.supported then object=candidate;info=result;break end end;if not object then return end
    local parent=menu:addOption("pz3d Assets",nil,nil);local sub=ISContextMenu:getNew(menu);menu:addSubMenu(parent,sub)
    sub:addOption(T("Choose replacement..."),object,function(o) C.open(o,"targets");local p=C.instance;for _,target in ipairs(p.state.targets) do if contains(info.tiles,target.tile) then p.source=target.source;break end end;p:refresh() end)
    sub:addOption(T(info.existing~="" and "Open my asset..." or "Create asset..."),object,function(o) C.open(o,"author");C.instance:createSelected() end)
    if info.existing~="" then
        local option=sub:addOption(T("Position asset..."),object,function(o) PZ3D.authorChoose(PZ3D.authorMenu().workingId,info.existing,true);PZ3DAuthorScene.open(C.instance,{id=info.existing},o) end)
        local state=PZ3D.authorMenu();for _,r in ipairs(state.cards) do if r.working and r.id==info.existing then option.notAvailable=not r.exported or not r.placeable;break end end
    end
end
Events.OnFillWorldObjectContextMenu.Add(context)
Events.OnGameStart.Add(function() if PZ3D and PZ3D.authorStart then PZ3D.authorStart() end end)
Events.OnTick.Add(function() if PZ3D and PZ3D.authorPoll then PZ3D.authorPoll() end end)
