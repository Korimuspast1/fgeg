require "ISUI/ISPanel"
require "ISUI/ISButton"
require "ISUI/ISScrollingListBox"
require "ISUI/ISRichTextPanel"
require "OptionScreens/MainScreen"
local entries = require "PZ3D/News"
local Model = require "PZ3D/NewsModel"
local Layout = require "PZ3DMenuLayout"
local model
local labels = {
    EN = { title="pz3d - What's new", all="Read all", close="Close", empty="No messages yet.", failed="Read history could not be saved. Please try Read all again." },
}
local function language() return Translator.getLanguage():name() end
local function label(key) return (labels[language()] or labels.EN)[key] end
local function available() return PZ3D and PZ3D.newsInitialized and PZ3D.newsSave end
local function mainMenu()
    local screen = MainScreen.instance
    return screen and not screen.inGame and screen:isVisible() and screen.bottomPanel and screen.bottomPanel:isVisible()
end
local function getModel()
    if not model and available() then model = Model.new(entries, PZ3D) end
    return model
end

PZ3DNewsPanel = ISPanel:derive("PZ3DNewsPanel")
function PZ3DNewsPanel:new(x,y,w,h)
    local o = ISPanel.new(self,x,y,w,h)
    o.backgroundColor={r=0.055,g=0.065,b=0.075,a=0.98}
    o.borderColor={r=0.30,g=0.36,b=0.40,a=1}
    o.moveWithMouse=true
    return o
end
function PZ3DNewsPanel:button(x,y,w,text,fn)
    local b=ISButton:new(x,y,w,28,text,self,fn)
    b:initialise();self:addChild(b);return b
end
function PZ3DNewsPanel:initialise()
    ISPanel.initialise(self)
    local left=math.floor(self.width*0.30)
    self.list=ISScrollingListBox:new(16,48,left-24,self.height-140)
    self.list:initialise();self.list:setFont(UIFont.Small,6)
    self.list:setOnMouseDownFunction(self,PZ3DNewsPanel.selectEntry);self:addChild(self.list)
    self.details=ISRichTextPanel:new(left,48,self.width-left-16,self.height-140)
    self.details:initialise();self.details.autosetheight=false;self.details:addScrollBars();self:addChild(self.details)
    self.all=self:button(16,self.height-44,230,label("all"),PZ3DNewsPanel.readAll)
    self.closeButton=self:button(self.width-146,self.height-44,130,label("close"),PZ3DNewsPanel.close)
    self:button(self.width-44,10,28,"X",PZ3DNewsPanel.close)
    self:refreshList()
end
function PZ3DNewsPanel:refreshList()
    local scroll=self.list:getYScroll()
    self.list:clear()
    for i,entry in ipairs(model.entries) do
        local text=model:translation(entry,language()).title
        self.list:addItem((model:unread(entry) and "* " or "") .. text,entry)
        if self.selected==entry then self.list.selected=i end
    end
    self.list:setYScroll(scroll)
    self.all:setEnable(model:hasUnread() or model.saved==false)
end
function PZ3DNewsPanel:showText(text)
    self.details.text=text:gsub("<","&lt;"):gsub(">","&gt;"):gsub("\n"," <LINE> ")
    self.details:paginate();self.details:setYScroll(0)
end
function PZ3DNewsPanel:selectEntry(entry)
    if not entry then return end
    local translation=model:translation(entry,language())
     
    self:showText(translation.title .. "\n\n" .. translation.text)
    self.selected=entry;model:read(entry);self:refreshList()
end
function PZ3DNewsPanel:readAll() model:readAll();self:refreshList() end
function PZ3DNewsPanel:close()
    self:setVisible(false)
    self:removeFromUIManager();PZ3DNewsPanel.instance=nil
end
function PZ3DNewsPanel:update()
    ISPanel.update(self)
    if not mainMenu() then self:close();return end
    local lang=language()
    if self.language~=lang then
        self.language=lang;self.all:setTitle(label("all"));self.closeButton:setTitle(label("close"))
        if self.selected then
            local translation=model:translation(self.selected,lang)
            self:showText(translation.title .. "\n\n" .. translation.text)
        end
        self:refreshList()
    end
end
function PZ3DNewsPanel:prerender()
    ISPanel.prerender(self)
    self:drawText(label("title"),16,14,0.92,0.95,1,1,UIFont.Medium)
    if model.saved==false then self:drawText(label("failed"),16,self.height-78,1,0.65,0.4,1,UIFont.Small) end
end
function PZ3DNewsPanel.open()
    if not mainMenu() or not getModel() then return end
    if PZ3DNewsPanel.instance then PZ3DNewsPanel.instance:close();return end
    local sw,sh=getCore():getScreenWidth(),getCore():getScreenHeight()
    local w,h=math.min(1000,sw-32),math.min(700,sh-32)
    local panel=PZ3DNewsPanel:new((sw-w)/2,(sh-h)/2,w,h)
    PZ3DNewsPanel.instance=panel;panel:initialise();panel:addToUIManager()
    panel.language=language()
    if model.entries[1] then panel:selectEntry(model.entries[1]) else panel:showText(label("empty")) end
end
local function install(screen)
    if not screen or screen.pz3dNews then return end
    local b=ISButton:new(screen.width-490,18,232,28,label("title"),nil,PZ3DNewsPanel.open)
    b:initialise();b:setAnchorRight(true);b:setAnchorLeft(false);b:setVisible(false)
    local nativeRender=b.render
    function b:render()
        nativeRender(self)
        if model and model:hasUnread() then self:drawRect(self.width-10,5,5,5,1,1,0.7,0.25) end
    end
    screen:addChild(b);screen.pz3dNews=b
end
local nativeInstantiate=MainScreen.instantiate
function MainScreen:instantiate() nativeInstantiate(self);install(self) end
local nativeUpdate=MainScreen.update
function MainScreen:update()
    nativeUpdate(self);install(self)
    local visible=mainMenu() and available() and true or false
    if self.pz3dNews then
        self.pz3dNews:setVisible(visible)
        if visible then
            getModel()
            if self.pz3dNews.language~=language() then
                self.pz3dNews.language=language();self.pz3dNews:setTitle(label("title"))
            end
            Layout.update(self)
        end
    end
    if not visible and PZ3DNewsPanel.instance then PZ3DNewsPanel.instance:close() end
end
Events.OnGameBoot.Add(function() install(MainScreen.instance) end)
Events.OnGameStart.Add(function() if PZ3DNewsPanel.instance then PZ3DNewsPanel.instance:close() end end)
install(MainScreen.instance)
