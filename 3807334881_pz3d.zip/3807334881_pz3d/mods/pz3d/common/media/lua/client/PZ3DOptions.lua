require "PZAPI/ModOptions"

 
local options = PZAPI.ModOptions:create("PZ3D", "pz3d")
local flags = {
    {"diagnostics", "Collect"}, {"diagnosticOverlay", "Overlay"},
    {"diagnosticRecording", "Record"}, {"diagnosticDetails", "Details"}, {"chunkDebug", "Chunks"},
    {"nativeLootCache", "Loot"}, {"deferLoot", "DeferLoot"}, {"skipIsoPreparation", "IsoPrep"},
    {"nativeTextureMips", "TextureMips"}, {"suppressIsoDraw", "IsoDraw"}, {"warmWorld", "WarmWorld"}
}
 
local function label(key) return "UI_PZ3D_Opt_" .. key end
 
options:addKeyBind("toggle3DKey", getText(label("Toggle3DKey")), Keyboard.KEY_INSERT)
options:addKeyBind("perspectiveKey", getText(label("PerspectiveKey")), Keyboard.KEY_NONE)
options:addSlider("firstPersonFov", label("FirstPersonFov"), 60, 120, 1, 95, label("FirstPersonFovTip"))
options:addTickBox("showDeviceCaptions", label("DeviceCaptions"), true)
local daylight = options:addComboBox("daylightPreset", label("DaylightPreset"), label("DaylightPresetTip"))
daylight:addItem(label("DaylightVanilla"), true)
daylight:addItem(label("DaylightRealistic"))
options:addButton("workingMod", "pz3d Assets Manager", "Browse asset packs, choose replacements or enter Creative mode", function()
    require "PZ3DModelCards"
    PZ3DModelCards.openPlay()
end)
options:addSeparator()
options:addTitle(label("Diagnostics"))
for i,row in ipairs(flags) do
    if i == 6 then options:addSeparator(); options:addTitle(label("Native")) end
    if row[1] == "warmWorld" then options:addSeparator(); options:addTitle(label("Streaming")) end
    options:addTickBox(row[1], label(row[2]), i >= 6 and row[1] ~= "nativeTextureMips", row[1] == "nativeTextureMips" and label("TextureMipsTip") or row[1] == "warmWorld" and label("WarmWorldTip") or row[1] == "deferLoot" and label("DeferLootTip") or row[1] == "chunkDebug" and label("ChunksTip") or i >= 6 and label("NativeTip") or nil)
end
options:addSeparator()
options:addKeyBind("diagnosticViewKey", getText(label("ExpandKey")), Keyboard.KEY_BACK)
options:addKeyBind("diagnosticCollectKey", getText(label("CollectKey")), Keyboard.KEY_BACK)
options:addDescription(label("Controls"))
options:addSeparator()
options:addTitle("UI_PZ3D_PerfTrees_Tab")
local treeValues = {{"treeLod0",12},{"treeLod1",28},{"treeLod2",52},{"treeLodBand",20},{"treeVariants",2}}
for i=0,2 do
    options:addSlider("treeLod"..i, "LOD "..i.." -> "..(i+1).." | "..getText(label("TreeDistance")), 2, 180+i*40, 1, treeValues[i+1][2])
end
options:addSlider("treeLodBand", label("TreeBand"), 5, 40, 1, 20)
options:addSlider("treeVariants", label("TreeVariants"), 1, 4, 1, 2)

 
 
local function sync()
    if not PZ3D or not PZ3D.clientOption then return end
    options:getOption("toggle3DKey"):setValue(PZ3D.clientKey("toggle3DKey", Keyboard.KEY_INSERT))
    options:getOption("perspectiveKey"):setValue(PZ3D.clientKey("perspectiveKey", Keyboard.KEY_NONE))
    options:getOption("firstPersonFov"):setValue(math.max(60, math.min(120, PZ3D.clientKey("firstPersonFov", 95))))
    options:getOption("showDeviceCaptions"):setValue(PZ3D.clientOption("showDeviceCaptions"))
    options:getOption("daylightPreset"):setValue(PZ3D.clientKey("daylightPreset", 1) == 2 and 2 or 1)
    for _,row in ipairs(flags) do options:getOption(row[1]):setValue(PZ3D.clientOption(row[1])) end
    options:getOption("diagnosticViewKey"):setValue(PZ3D.clientKey("diagnosticViewKey", Keyboard.KEY_BACK))
    options:getOption("diagnosticCollectKey"):setValue(PZ3D.clientKey("diagnosticCollectKey", Keyboard.KEY_BACK))
    for _,row in ipairs(treeValues) do options:getOption(row[1]):setValue(PZ3D.clientKey(row[1],row[2])) end
end
function options:apply()
    if not PZ3D or not PZ3D.setClientOption then return end
     
    for _,option in ipairs(self.data) do
        if option.type == "keybind" and option.element then
            option:setValue(option.element.keyCode)
        end
    end
    PZ3D.setClientKey("toggle3DKey", self:getOption("toggle3DKey"):getValue())
    PZ3D.setClientKey("perspectiveKey", self:getOption("perspectiveKey"):getValue())
    PZ3D.setClientKey("firstPersonFov", math.max(60, math.min(120, math.floor(self:getOption("firstPersonFov"):getValue()+0.5))))
    PZ3D.setClientOption("showDeviceCaptions", self:getOption("showDeviceCaptions"):getValue())
    PZ3D.setClientKey("daylightPreset", self:getOption("daylightPreset"):getValue())
    for _,row in ipairs(flags) do PZ3D.setClientOption(row[1], self:getOption(row[1]):getValue()) end
    PZ3D.setClientKey("diagnosticViewKey", self:getOption("diagnosticViewKey"):getValue())
    PZ3D.setClientKey("diagnosticCollectKey", self:getOption("diagnosticCollectKey"):getValue())
     
    local previous=0
    for i=0,2 do
        local option=self:getOption("treeLod"..i)
        local value=math.max(previous+2,math.floor(option:getValue()+0.5))
        option:setValue(value);previous=value
    end
    for _,row in ipairs(treeValues) do PZ3D.setClientKey(row[1], math.floor(self:getOption(row[1]):getValue()+0.5)) end
end
local nativeLoad = PZAPI.ModOptions.load
function PZAPI.ModOptions:load(...)
    nativeLoad(self, ...)
    sync()
end
Events.OnGameBoot.Add(sync)
Events.OnGameStart.Add(sync)
