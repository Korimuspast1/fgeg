 
if not getDebug() then return end
local ok=pcall(require,"ModStudio/ScenarioAPI")
if not ok or not ModStudio or not ModStudio.Scenarios then return end
local API=ModStudio.Scenarios
local manifestSamples={}
local owned,recording,drainAt,ended,oldView,oldMode=false,false,nil,false,nil,nil
local function checkNumber(s,k,min,max,optional)
    local v=s[k];assert(optional and v==nil or type(v)=="number" and v==v and v>=min and v<=max,"Invalid "..k)
end
local function clear(c) PZ3D.scenarioClearMotion();if c.player then c.player:setRunning(false);c.player:setSprinting(false) end end
local function ready(c)
    assert(PZ3D and PZ3D.scenarioControlStart,"PZ3D scenario API unavailable")
    if not oldMode then oldMode=PZ3D.cameraMode();oldView=PZ3D.scenarioView() end
    if PZ3D.cameraMode()==0 then PZ3D.cameraMode(1);return false end
    if not owned then assert(PZ3D.scenarioControlStart(),"PZ3D controls busy");owned=true;PZ3D.scenarioTakeControls() end
    return true
end
local function finish(c,status,reason)
    clear(c)
    if PZ3DModelCards and PZ3DModelCards.instance then PZ3DModelCards.instance:close() end
    if PZ3D.scenarioInteractionClear then PZ3D.scenarioInteractionClear() end
    if PZ3D.scenarioVisualConditionsClear then PZ3D.scenarioVisualConditionsClear() end
    if PZ3DLightingDebug and PZ3DLightingDebug.instance then PZ3DLightingDebug.instance:close() end
    if PZ3D.scenarioUi then PZ3D.scenarioUi(false) end
    if PZ3D.lightingReset then PZ3D.lightingReset() end
    if PZ3D.scenarioVariantClear then PZ3D.scenarioVariantClear() end
    if not drainAt then drainAt=c.clock();if recording then PZ3D.scenarioPhase(c.repeatIndex,c.stepIndex,"DRAIN") end end
    if recording and c.clock()-drainAt<2 then PZ3D.scenarioHeartbeat();return false end
    if recording and not ended then PZ3D.scenarioEnd(status,reason);ended=true;c.event("pz3d-artifact",PZ3D.scenarioPath()) end
    if recording and not PZ3D.scenarioFinished() then return false end
    local diagnosticStatus=recording and PZ3D.scenarioStatus() or "complete"
    if oldView and owned then PZ3D.scenarioLook(oldView.yaw,oldView.pitch) end
    if owned then PZ3D.scenarioControlEnd();owned=false end
    if oldMode then PZ3D.cameraMode(oldMode) end
    manifestSamples={}
    if status=="complete" then assert(not string.find(diagnosticStatus,"^invalid") and not string.find(diagnosticStatus,"^failed"),"PZ3D diagnostic recording failed: "..diagnosticStatus) end
    return true
end
API.register("pz3d",{
    begin=ready,
    update=function(c) PZ3D.scenarioHeartbeat();assert(PZ3D.scenarioInterruption()=="",PZ3D.scenarioInterruption());assert(PZ3D.cameraMode()>0,"3D disabled") end,
    boundary=clear,
    nativeAction=function(c,action) if action=="teleport" then PZ3D.scenarioAdoptNativePosition();c.event("pz3d-native-position","adopted native teleport") end end,
    phase=function(c,name) if recording then PZ3D.scenarioPhase(c.repeatIndex,c.stepIndex,name) end end,
    finish=finish
},{
    assetMemory={validate=function(s)
            assert(type(s.label)=="string" and #s.label>0 and #s.label<=80,"Invalid memory sample label")
            assert(s.closed==nil or type(s.closed)=="boolean","Invalid closed expectation")
            assert(s.sameReadsAs==nil or type(s.sameReadsAs)=="string","Invalid metadata sample label")
        end,
        start=function(c,s) c.phase("TRANSITION",s.timeout or 15) end,
        tick=function(c,s)
            local m=PZ3D.scenarioAssetMemory()
            if s.sameReadsAs then assert(manifestSamples[s.sameReadsAs]~=nil and m.manifestReads==manifestSamples[s.sameReadsAs],"Asset manifest was reread after "..s.sameReadsAs) end
            manifestSamples[s.label]=m.manifestReads
            if s.closed then
                if m.previewJobs>0 or m.previewRetirements>0 then return false end
                for _,key in ipairs({"previewDecodedBytes","previewGpuBytes","previewScenes","previewThumbnails","thumbnailCacheEntries","previewSourceEntries"}) do assert(m[key]==0,key.." retained after close: "..m[key]) end
                assert(not m.catalogCached,"Catalog projection retained after close")
            end
            local values={s.label};for _,key in ipairs({"manifestReads","manifestLoadMillis","installedCards","installedModelFiles","heapUsedBytes","worldModelBytes","previewDecodedBytes","previewGpuBytes","previewScenes","previewThumbnails","previewJobs","previewRetirements","thumbnailCacheEntries","previewSourceEntries"}) do table.insert(values,key.."="..m[key]) end
            c.event("pz3d-asset-memory",table.concat(values," "));return true
        end},
    assetsBrowse={validate=function(s)
            assert(type(s.mod)=="string" and #s.mod>0,"assetsBrowse requires mod")
            checkNumber(s,"count",1,10000);assert(s.count==math.floor(s.count),"Invalid browse count")
            checkNumber(s,"cards",1,65536);assert(s.cards==math.floor(s.cards),"Invalid expected card count")
        end,
        start=function(c,s)
            require "PZ3DModelCards";PZ3DModelCards.open(nil,"packs");c.assetBrowse={at=1,rows=nil,selected=false,maxGpu=0,maxThumbnails=0};c.phase("TRANSITION",s.timeout or 180)
        end,
        tick=function(c,s)
            local p=PZ3DModelCards.instance;assert(p,"Asset manager did not open");local b=c.assetBrowse
            if not b.rows then
                p:refresh();local rows={};for _,row in ipairs(p.state.cards) do if row.mod==s.mod and not row["local"] then table.insert(rows,row) end end
                if #rows<s.cards then return false end;assert(#rows==s.cards,"Unexpected card count: "..#rows);assert(s.count<=#rows,"Browse count exceeds card count");b.rows=rows;p.pack=rows[1].pack;p:refresh()
            end
            if not b.selected then local at=1+math.floor((b.at-1)*#b.rows/s.count);p:selectRow(b.rows[at]);for i,item in ipairs(p.list.items) do if item.item.id==p.row.id then p.list.selected=i;p.list:ensureVisible(i);break end end;b.selected=true;b.started=c.clock() end
            local live=p:livePreview();local thumb=p:preview(p.file)
            assert(not live or live.error=="",live and live.error);assert(not thumb or thumb.error=="",thumb and thumb.error)
            assert(c.clock()-b.started<20,"Preview timed out: "..tostring(p.file))
            local m=PZ3D.scenarioAssetMemory();b.maxGpu=math.max(b.maxGpu,m.previewGpuBytes);b.maxThumbnails=math.max(b.maxThumbnails,m.previewThumbnails)
            assert(m.thumbnailCacheEntries<=24 and m.previewSourceEntries<=32,"Preview cache limit exceeded")
            if live and live.texture and thumb and thumb.texture then
                if b.at==s.count then c.event("pz3d-assets-browsed","cards="..#b.rows.." previewed="..b.at.." maxGpuBytes="..b.maxGpu.." maxThumbnails="..b.maxThumbnails);c.assetBrowse=nil;return true end
                b.at=b.at+1;b.selected=false
            end
            return false
        end},
    interaction={validate=function(s)
            assert(type(s.action)=="string" and PZ3D.scenarioInteractionKnown(s.action),"Unknown interaction probe action")
            assert(s.kind==nil or s.kind=="door" or s.kind=="switch","Invalid interaction kind")
            checkNumber(s,"radius",.1,3,true)
        end,
        start=function(c,s) assert(recording,"Enable diagnostics first");c.interactionState=nil;PZ3D.scenarioInteraction(s.action,s.kind or "door",s.radius or 3);c.phase("TRANSITION",s.timeout or 15) end,
        tick=function(c,s) local state=PZ3D.scenarioInteractionStatus();if state~=c.interactionState then c.interactionState=state;c.event("pz3d-interaction",state) end;return string.find(state,"^ready ")~=nil end},
    modelsPanel={validate=function(s)
            assert(type(s.open)=="boolean","modelsPanel requires open")
            assert(s.view==nil or s.view=="play" or s.view=="packs" or s.view=="targets" or s.view=="author","Invalid modelsPanel view")
            for _,k in ipairs({"card","mod","file"}) do assert(s[k]==nil or type(s[k])=="string" and #s[k]>0 and #s[k]<=512,"Invalid modelsPanel "..k) end
            assert(s.expect==nil or s.expect=="ready" or s.expect=="error" or s.expect=="missing","Invalid preview expectation")
            checkNumber(s,"yaw",-3600,3600,true);checkNumber(s,"pitch",-89,89,true);checkNumber(s,"zoom",.25,4,true)
        end,
        start=function(c,s)
            require "PZ3DModelCards";c.assetPanelRestore=nil;c.assetPanelChecked=false
            if s.open then PZ3DModelCards.open(nil,s.view or "play");c.phase("TRANSITION",s.timeout or 30)
            elseif PZ3DModelCards.instance then local p=PZ3DModelCards.instance;c.assetPanelRestore={ui=p.previousUi,speed=p.previousSpeed};p:close() end
        end,
        tick=function(c,s)
            if not s.open then
                assert(not PZ3DModelCards.instance,"Asset manager did not close")
                local previous=c.assetPanelRestore
                if previous then
                    if previous.speed~=nil then assert(getGameSpeed()==previous.speed,"Asset manager did not restore native speed")
                    elseif previous.ui~=nil and getGameSpeed()~=0 then assert(PZ3D.ui()==previous.ui,"Asset manager did not restore Tab mode") end
                end
                c.event("pz3d-assets-controls","closed camera="..PZ3D.cameraMode().." ui="..tostring(PZ3D.ui()).." speed="..getGameSpeed());return true
            end
            local p=PZ3DModelCards.instance;assert(p,"Model menu did not open");p:refresh()
            assert(not PZ3D.capture(),"Asset manager retained mouse capture")
            if PZ3D.nativeControls() then assert(getGameSpeed()==0,"Asset manager did not pause Top Down")
            else assert(PZ3D.inventoryUi() or getGameSpeed()==0,"Asset manager did not enter Tab mode") end
            if not c.assetPanelChecked then c.assetPanelChecked=true;c.event("pz3d-assets-controls","open camera="..PZ3D.cameraMode().." ui="..tostring(PZ3D.ui()).." speed="..getGameSpeed()) end
            if s.card then
                local chosen
                for _,row in ipairs(p.state.cards) do if row.id==s.card and (not s.mod or row.mod==s.mod) then chosen=row;break end end
                if not chosen then local status="waiting asset, catalog="..#p.state.cards;if c.assetStatus~=status then c.assetStatus=status;c.event("pz3d-assets",status) end;return false end;p.pack=chosen.pack;if p.view=="targets" then p.source=chosen.sources[1] end;p:refresh();p:selectRow(chosen)
            end
            if s.file then
                local found=false;for _,item in ipairs(p.gallery.items) do if item.item==s.file then found=true end end
                assert(found,"Model file not listed: "..s.file);p:selectFile(s.file)
                p.yaw=s.yaw or p.yaw;p.pitch=s.pitch or p.pitch;p.zoom=s.zoom or p.zoom
                local preview=p:livePreview()
                local status="file="..s.file.." texture="..tostring(preview and preview.texture~=nil).." phase="..tostring(preview and preview.phase).." error="..tostring(preview and preview.error);if c.assetStatus~=status then c.assetStatus=status;c.event("pz3d-assets",status) end
                if s.expect=="missing" then return preview and preview.missing==true end
                if s.expect=="error" then return preview and preview.error~="" end
                assert(not preview or preview.error=="",preview and preview.error);return preview and preview.texture~=nil
            end
            return true
        end},
    visualConditions={validate=function(s) assert(type(s.action)=="string" and PZ3D.scenarioVisualConditionsKnown(s.action),"Unknown visual conditions action") end,
        start=function(c,s) c.visualConditionState=nil;PZ3D.scenarioVisualConditions(s.action,c.output);c.phase("TRANSITION",s.timeout or 30) end,
        tick=function(c,s) local state=PZ3D.scenarioVisualConditionsStatus();if state~=c.visualConditionState then c.visualConditionState=state;c.event("pz3d-visual-conditions",state) end;return string.find(state,"^ready ")~=nil end},
    lighting={validate=function(s)
            assert(type(s.mode)=="string" and PZ3D.lightingModeKnown(s.mode),"Unknown lighting mode")
            for _,k in ipairs({"shape","sun","torch","freeze"}) do assert(s[k]==nil or type(s[k])=="boolean","Invalid "..k) end
        end,
        start=function(c,s) assert(PZ3D.lightingMode(s.mode,s.shape~=false,s.sun~=false,s.torch~=false,s.freeze==true),"Cannot request lighting mode");c.phase("TRANSITION",s.timeout or 30) end,
        tick=function(c,s) local state=PZ3D.lightingState();assert(state.error=="",state.error);if PZ3D.lightingReady() then c.event("pz3d-lighting",s.mode.." cells="..state.cells.." held="..state.held);return true end;return false end},
    lightingProbe={validate=function(s) assert(s.name==nil or type(s.name)=="string" and #s.name<=80,"Invalid probe name") end,
        start=function(c,s) c.event("pz3d-native-light-probe",(s.name or "sample").." "..PZ3D.lightingProbe()) end},
    lightingPanel={validate=function(s) assert(type(s.open)=="boolean","lightingPanel requires open") end,
        start=function(c,s) assert(PZ3DLightingDebug,"Lighting panel not loaded");PZ3D.scenarioUi(s.open);if s.open then PZ3DLightingDebug.open();assert(PZ3DLightingDebug.instance,"Lighting panel unavailable") elseif PZ3DLightingDebug.instance then PZ3DLightingDebug.instance:close() end end},
    variant={validate=function(s) assert(type(s.name)=="string" and PZ3D.scenarioVariantKnown(s.name),"Unknown PZ3D render variant") end,
        start=function(c,s) assert(recording,"Enable diagnostics first");assert(PZ3D.scenarioVariant(s.name),"Cannot select render variant");c.event("pz3d-render-variant",s.name) end},
    camera={validate=function(s) checkNumber(s,"mode",1,3);assert(s.mode==math.floor(s.mode),"Invalid camera mode") end,
        start=function(c,s) PZ3D.cameraMode(s.mode) end},
    diagnostics={validate=function(s) assert(type(s.enabled)=="boolean","diagnostics requires enabled") end,
        start=function(c,s)
            if s.enabled then
                assert(not recording,"Diagnostics already running");assert(PZ3D.scenarioDiagnosticsStart(c.json,c.output),"Cannot start PZ3D diagnostics")
                recording=true;ended=false;drainAt=nil;c.event("diagnostics","pz3d enabled")
            else assert(recording,"Diagnostics not running");c.phase("DRAIN",15);drainAt=c.clock() end
        end,
        tick=function(c,s)
            if s.enabled then return PZ3D.scenarioReady() end
            if c.clock()-drainAt<2 then return false end
            if not ended then PZ3D.scenarioEnd("complete","Diagnostics disabled by scenario");ended=true end
            if not PZ3D.scenarioFinished() then return false end
            assert(not string.find(PZ3D.scenarioStatus(),"^invalid") and not string.find(PZ3D.scenarioStatus(),"^failed"),"PZ3D diagnostic recording failed: "..PZ3D.scenarioStatus())
            c.event("pz3d-artifact",PZ3D.scenarioPath());c.event("diagnostics","pz3d disabled");recording=false;drainAt=nil;return true
        end},
    look={validate=function(s) checkNumber(s,"yaw",-1000,1000);checkNumber(s,"pitch",-1.5,1.5,true) end,
        start=function(c,s) PZ3D.scenarioLook(s.yaw,s.pitch or 0) end},
    move={validate=function(s) checkNumber(s,"x",0,100000);checkNumber(s,"y",0,100000);checkNumber(s,"z",-32,31,true);checkNumber(s,"tolerance",.05,2,true) end,
        start=function(c,s) c.moveDistance=math.huge;c.moveProgress=c.clock();c.phase("MEASURE",s.timeout or 30) end,
        tick=function(c,s,t)
            local p=c.player;local dx,dy=s.x-p:getX(),s.y-p:getY();local distance=math.sqrt(dx*dx+dy*dy)
            assert(math.abs(p:getZ()-(s.z or 0))<.25,"Unexpected route floor")
            if distance<(s.tolerance or .25) then c.event("route-arrived","distance="..distance.." seconds="..t);return true end
            if distance<c.moveDistance-.1 then c.moveDistance=distance;c.moveProgress=c.clock() end
            assert(c.clock()-c.moveProgress<5,"Route stuck; no teleport correction")
            PZ3D.scenarioLook(math.atan2(dy,dx),s.pitch or 0);p:setRunning(s.run==true);PZ3D.scenarioMotion(1,0,s.run==true)
            return false
        end},
    sweep={validate=function(s) checkNumber(s,"seconds",.1,600);checkNumber(s,"yaw",-1000,1000,true);checkNumber(s,"radians",-1000,1000,true) end,
        start=function(c,s) c.phase("MEASURE",s.seconds+5) end,
        tick=function(c,s,t) PZ3D.scenarioLook((s.yaw or 0)+(s.radians or 6.2831853)*math.min(1,t/s.seconds),s.pitch or 0);return t>=s.seconds end},
    measure={validate=function(s) checkNumber(s,"seconds",.1,600) end,start=function(c,s) assert(recording,"Enable diagnostics first");c.phase(c.nonconverged and "MEASURE_NONCONVERGED" or "MEASURE",s.seconds+5) end,
        tick=function(c,s,t) return t>=s.seconds end},
    warmup={validate=function(s) checkNumber(s,"seconds",.1,600);assert(s.strict==nil or type(s.strict)=="boolean","Invalid strict warmup") end,start=function(c,s) assert(recording,"Enable diagnostics first");c.stableAt=nil;c.nonconverged=true;c.phase("WARMUP",s.seconds+5) end,
        tick=function(c,s,t)
            if PZ3D.scenarioSettled() then c.stableAt=c.stableAt or c.clock() else c.stableAt=nil end
            if c.stableAt and c.clock()-c.stableAt>=3 and t>=math.min(10,s.seconds) then c.nonconverged=false;return true end
            if t>=s.seconds then assert(not s.strict,"Warmup ended with unfinished queues");c.event("nonconverged","Warmup ended with unfinished queues");return true end
            return false
        end},
    capture={start=function(c) assert(recording,"Enable diagnostics first");c.phase("CAPTURE",10);PZ3D.scenarioCapture() end,tick=function() return PZ3D.scenarioCaptured() end},
    awaitTorch={validate=function(s) assert(type(s.on)=="boolean","awaitTorch requires on") end,start=function(c,s) c.phase("TRANSITION",s.timeout or 10) end,
        tick=function(c,s,t) local n=tonumber(string.match(PZ3D.scenarioRenderState(),"coneHand=(%d+)"));if n and ((s.on and n>0) or (not s.on and n==0)) then c.event("pz3d-beam-observed",t);return true end;return false end}
})
