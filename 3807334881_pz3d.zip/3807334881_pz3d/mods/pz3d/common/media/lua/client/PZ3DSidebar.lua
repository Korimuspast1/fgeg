require "ISUI/ISEquippedItem"
require "ISUI/ISButton"
require "ISUI/ISContextMenu"
require "ISUI/ISPanel"

local function viewRows()
    return {{0, "ISO", "ISO"}, {1, getText("UI_PZ3D_View_First"), "1st"},
        {2, getText("UI_PZ3D_View_Third"), "3rd"}, {3, "Top Down", "Top"}}
end

local function closeFan(button)
    local fan = button.pz3dFan
    if not fan then return end
    button.pz3dFan = nil
    fan.dragging = false
    fan:setCapture(false)
    fan:setVisible(false)
    fan:removeFromUIManager()
end

local function contains(element, x, y)
    local left, top = element:getAbsoluteX(), element:getAbsoluteY()
    return x >= left and y >= top and x < left + element:getWidth() and y < top + element:getHeight()
end

local function chooseView(button, option)
    closeFan(button)
    if PZ3D and PZ3D.cameraMode then PZ3D.cameraMode(option.pz3dView) end
end

local nativeOptionRender = ISButton.render
local function renderOption(option)
    nativeOptionRender(option)
    local selected = option.target.pz3dMode == option.pz3dView
    local alpha = ((selected or option.mouseOver) and 1 or 0.45) * option.textureColor.a
    option:drawTextureScaled(option.pz3dRing, 0, 0, option:getWidth(), option:getHeight(), alpha,
        selected and 0.35 or 1, selected and 0.85 or 1, 1)
end

local function releaseFan(button)
    local fan = button.pz3dFan
    if not fan or not fan.dragging then return true end
    fan.dragging = false
    fan:setCapture(false)
    local x, y = getMouseX(), getMouseY()
     
    if contains(button, x, y) then return true end
    for _, option in ipairs(fan.options) do
        if contains(option, x, y) then chooseView(button, option); return true end
    end
    closeFan(button)
    return true
end

local function toggleFan(button)
    if button.pz3dFan then closeFan(button); return end
    if not PZ3D or not PZ3D.cameraMode then return end
    local width = button:getWidth()
    local size, radius = math.max(32, math.floor(width * 0.65)), width * 1.25
    local height = math.ceil(radius * math.sqrt(3) + size)
    local fan = ISPanel:new(0, 0, math.ceil(width + 4 + radius + size/2), height)
    fan:initialise(); fan:instantiate()
    fan.background = false
    fan.prerender = function() end
    fan.options = {}
    fan.openedAt = getTimestampMs()
    fan.dragging = true
    fan.onMouseDown = function() closeFan(button); return true end
    fan.onRightMouseDown = fan.onMouseDown
    local function outside()
         
        local x, y = getMouseX(), getMouseY()
         
        if not contains(button, x, y) and not contains(fan, x, y) then closeFan(button) end
    end
    fan.onMouseDownOutside = outside
    fan.onRightMouseDownOutside = outside
    fan.onMouseUp = function() return releaseFan(button) end
    fan.onMouseUpOutside = fan.onMouseUp
    fan.update = function(self)
        if not button.target:getIsVisible() or not PZ3D or not PZ3D.cameraMode then closeFan(button); return end
        self:setX(math.max(0, math.min(getCore():getScreenWidth() - self:getWidth(), button:getAbsoluteX())))
        self:setY(math.max(0, math.min(getCore():getScreenHeight() - height, button:getAbsoluteY() + button:getHeight()/2 - height/2)))
        local t = math.max(0, math.min(1, (getTimestampMs() - self.openedAt)/180))
        local progress = 1 - (1-t)^3
        local rotation = -0.65*(1-progress)
        local c, s = math.cos(rotation), math.sin(rotation)
        local ox = button:getAbsoluteX() + width/2 - self:getAbsoluteX()
        local oy = button:getAbsoluteY() + button:getHeight()/2 - self:getAbsoluteY()
        for _, option in ipairs(self.options) do
            local dx, dy = option.fanX, option.fanY
            option.textureColor.a = progress
            option:setX(math.floor(ox + progress*(dx*c-dy*s) - size/2))
            option:setY(math.floor(oy + progress*(dx*s+dy*c) - size/2))
        end
    end
    for i, row in ipairs(viewRows()) do
        local angle = math.rad(-60 + (i-1)*40)
        local option = ISButton:new(0, 0, size, size, "", button, chooseView)
        option:initialise(); option:instantiate()
        option:setDisplayBackground(false)
        option:setImage(getTexture("media/ui/PZ3D/" .. tostring(width) .. "/" .. row[3] .. ".png"))
        option:forceImageSize(size*0.84, size*0.63)
        option:setTooltip(row[2])
        option.pz3dView = row[1]
        option.pz3dRing = getTexture("media/ui/PZ3D/" .. tostring(width) .. "/ModeRing.png")
        option.render = renderOption
        option.fanX = width/2 + 4 + radius*math.cos(angle)
        option.fanY = radius*math.sin(angle)
        table.insert(fan.options, option)
        fan:addChild(option)
    end
    button.pz3dFan = fan
    fan:addToUIManager()
    fan:setCapture(true)
    fan:update()
end

local function selectView(mode)
    if PZ3D and PZ3D.cameraMode then PZ3D.cameraMode(mode) end
end

local function cameraMenu(button)
    if not PZ3D or not PZ3D.cameraMode then return false end
    closeFan(button)
    local player = button.target.chr
    local context = ISContextMenu.get(player and player:getPlayerNum() or 0, getMouseX(), getMouseY())
    local current = PZ3D.cameraMode()
    for _, row in ipairs({{0, "ISO"}, {2, getText("UI_PZ3D_View_Third")}, {1, getText("UI_PZ3D_View_First")}, {3, "Top Down (Experimental)"}}) do
        local option = context:addOption(row[2], row[1], selectView)
        context:setOptionChecked(option, current == row[1])
    end
    if PZ3D.topDownOrthographic then
        local option = context:addOption("Top Down: Orthographic", nil, function()
            PZ3D.topDownOrthographic(not PZ3D.topDownOrthographic())
        end)
        context:setOptionChecked(option, PZ3D.topDownOrthographic())
    end
    return true
end

 
local function prepareProgress(button)
    local path = "media/ui/PZ3D/" .. tostring(button:getWidth()) .. "/"
    button.pz3dProgress = {}
    for frame = 0, 5 do
        button.pz3dProgress[frame + 1] = getTexture(path .. "Progress-" .. frame .. ".png")
    end
end

local nativeButtonRender = ISButton.render
local function renderMode(button)
    nativeButtonRender(button)
    if not button.pz3dBusy then return end
    local frame = math.floor(button.pz3dElapsed / 160) % 6
    button:drawTexture(button.pz3dProgress[frame + 1], 0, 0, 1, 1, 1, 1)
end

local function refreshMode(button)
    local available = PZ3D and PZ3D.cameraMode ~= nil
    local active = available and PZ3D.active() or false
    local mode = active and (PZ3D.cameraMode and PZ3D.cameraMode() or 2) or 0
    button:setEnable(available == true)
    if not available then closeFan(button) end
    local elapsed = available and PZ3D.transitionMillis and PZ3D.transitionMillis() or -1
    local busy = elapsed >= 250
    button.pz3dElapsed = elapsed
    if button.pz3dMode ~= mode or button.pz3dBusy ~= busy then
        button.pz3dBusy = busy
        button.pz3dMode = mode
        button.pz3dActive = active
        local texture = mode == 0 and button.isoTexture or (mode == 1 and button.firstTexture or (mode == 3 and button.topTexture or button.thirdTexture))
        if busy then button:setImage(nil) else button:setImage(texture) end
        for _, row in ipairs(viewRows()) do
            if row[1] == mode then button:setTooltip(row[2] .. "\n" .. getText("UI_PZ3D_View_Menu")) end
        end
    end
end

local nativeInitialise = ISEquippedItem.initialise
function ISEquippedItem:initialise()
    nativeInitialise(self)
    if not self.invBtn or self.pz3dModeButton then return end

    local first = self.invBtn
    local x, y, width, height = first:getX(), first:getY(), first:getWidth(), first:getHeight()
    local spacing = self.healthBtn:getY() - first:getBottom()
    local offset = height + spacing
     
    for _, child in pairs(self:getChildren()) do
        if child:getY() >= y then child:setY(child:getY() + offset) end
    end
     
    for _, name in ipairs({"movablePopup", "mapPopup", "metaPopup"}) do
        local popup = self[name]
        if popup then popup:setY(popup:getY() + offset) end
    end
    self:setHeight(self:getHeight() + offset)

    local button = ISButton:new(x, y, width, height, "", self, nil)
    button:initialise()
    button:instantiate()
    button:setDisplayBackground(false)
    button:ignoreWidthChange()
    button:ignoreHeightChange()
    button.onMouseDown = function(self) toggleFan(self); return true end
    button.onMouseDoubleClick = button.onMouseDown
    button.onMouseUp = function(self) return releaseFan(self) end
    button.onMouseUpOutside = button.onMouseUp
    button.onRightMouseUp = cameraMenu
    button.onRightMouseDown = function() return true end
    local path = "media/ui/PZ3D/" .. tostring(width) .. "/"
    button.isoTexture = getTexture(path .. "ISO.png")
    button.firstTexture = getTexture(path .. "3D-1st.png")
    button.thirdTexture = getTexture(path .. "3D-3rd.png")
    button.topTexture = getTexture(path .. "3D-Top.png")
    prepareProgress(button)
    button.render = renderMode
    self.pz3dModeButton = button
    self:addChild(button)
    refreshMode(button)
end

local nativePrerender = ISEquippedItem.prerender
function ISEquippedItem:prerender()
    nativePrerender(self)
    if self.pz3dModeButton then refreshMode(self.pz3dModeButton) end
end
