 
 
 
 
local function install()
    local conversion=ISCoordConversion
    if not conversion or type(conversion.ToWorld)~="function" or type(conversion.ToScreen)~="function" then return end
    if conversion.pz3dTopDownInstalled then return end
    local nativeToWorld,nativeToScreen=conversion.ToWorld,conversion.ToScreen
    function conversion.ToWorld(x,y,z)
        if not PZ3D or not PZ3D.nativeControls() then return nativeToWorld(x,y,z) end
        local zoom=getCore():getZoom(0)
        return PZ3D.topDownWorldX(x/zoom,y/zoom,z),PZ3D.topDownWorldY(x/zoom,y/zoom,z)
    end
    function conversion.ToScreen(x,y,z,cz)
        if not PZ3D or not PZ3D.nativeControls() then return nativeToScreen(x,y,z,cz) end
        local zoom=getCore():getZoom(0)
        return PZ3D.topDownScreenX(x,y,z)*zoom,PZ3D.topDownScreenY(x,y,z)*zoom
    end
    conversion.pz3dTopDownInstalled=true
end
Events.OnGameBoot.Add(install)
Events.OnGameStart.Add(install)
install()
