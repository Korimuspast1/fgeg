require "DebugUIs/DebugMenu/ISDebugMenu"
require "ISUI/ISButton"
require "ISUI/ISComboBox"
require "ISUI/ISTextEntryBox"

local months={"January","February","March","April","May","June","July","August","September","October","November","December"}
PZ3DTreeDebug=ISPanel:derive("PZ3DTreeDebug")
local Panel=PZ3DTreeDebug
local function available() return PZ3D and PZ3D.treeDebugAvailable and PZ3D.treeDebugAvailable() end
function Panel:new(x,y,w,h)
    local o=ISPanel.new(self,x,y,w,h)
    o.backgroundColor={r=.06,g=.07,b=.08,a=.97};o.borderColor={r=.35,g=.4,b=.42,a=1}
    o.moveWithMouse=true;o.labels={};o.nextRefresh=0
    return o
end
function Panel:label(text,y)
    table.insert(self.labels,{text=text,y=y})
end
function Panel:button(text,x,y,w,action)
    local b=ISButton:new(x,y,w,self.rh-4,text,self,function() self:run(action) end)
    b:initialise();self:addChild(b);return b
end
function Panel:combo(x,y,w,items,action)
    local c=ISComboBox:new(x,y,w,self.rh-4,self,action)
    c:initialise();for _,v in ipairs(items) do c:addOption(v) end;self:addChild(c);return c
end
function Panel:entry(text,x,y,w)
    local e=ISTextEntryBox:new(text,x,y,w,self.rh-4);e:initialise();self:addChild(e);return e
end
function Panel:run(action)
    if not available() then self.message="Single-player debug session required.";return end
    local ok,err=pcall(action)
    if not ok then self.message=tostring(err) end
    self.nextRefresh=0
end
function Panel:createChildren()
    ISPanel.createChildren(self)
    self.rh=getTextManager():getFontHeight(UIFont.Small)+12
    local r=self.rh;local y=12
    self:label("pz3d | Trees",y)
    self:button("X",self.width-42,6,30,function() self:close() end)
    y=y+r
    self:label("Game date and time",y);y=y+r
    self.day=self:combo(12,y,64,{"1"})
    self.month=self:combo(82,y,158,months,function() self:days() end)
    self.year=self:entry("1993",246,y,72)
    self.year.onTextChange=function() self:days() end
    self:button("Apply",324,y,184,function()
        local year=tonumber(self.year:getText());if not year or year<1900 or year>2100 then self.message="Year: 1900-2100";return end
        PZ3D.treeDebugDate(year,self.month.selected,self.day.selected);self:syncDate()
    end);y=y+r
    local shifts={{"- month",0,-1},{"- day",-1,0},{"+ day",1,0},{"+ month",0,1}}
    for i,v in ipairs(shifts) do local d,m=v[2],v[3];self:button(v[1],12+(i-1)*125,y,121,function() PZ3D.treeDebugShift(d,m);self:syncDate() end) end;y=y+r
    local times={{"Morning 06",6},{"Day 12",12},{"Evening 18",18},{"Night 00",0}}
    for i,v in ipairs(times) do local hour=v[2];self:button(v[1],12+(i-1)*125,y,121,function() PZ3D.treeDebugTime(hour,0);self:syncDate() end) end;y=y+r
    self.clock=self:entry("12:00",12,y,86)
    self:button("Set time",104,y,136,function()
        local h,m=self.clock:getText():match("^(%d%d?):(%d%d)$");h=tonumber(h);m=tonumber(m)
        if not h or h>23 or m>59 then self.message="Time: HH:MM, 00:00-23:59";return end
        PZ3D.treeDebugTime(h,m);self:syncDate()
    end)
    self.nowY=y;y=y+r+6
    self:label("Tree snow | temporary preview",y);y=y+r
    for i,value in ipairs({0,25,50,75,100}) do local amount=value;self:button(value.."%",12+(i-1)*70,y,66,function() PZ3D.treeDebugSnow(amount) end) end
    self:button("Weather",362,y,146,function() PZ3D.treeDebugSnow(-1) end);y=y+r+6
    self:label("3D age | temporary, save data unchanged",y);y=y+r
    self.mode=self:combo(12,y,260,{"Under crosshair","Around player"})
    self.radius=self:combo(278,y,230,{"Radius 5 m","Radius 10 m","Radius 20 m","Radius 30 m"});self.radius.selected=2;y=y+r
    for i,delta in ipairs({-1,1}) do local step=delta;self:button("Age "..(delta<0 and "-1" or "+1"),12+(i-1)*125,y,121,function()
        local n=PZ3D.treeDebugAge(step,self.mode.selected==2,({5,10,20,30})[self.radius.selected])
        self.message=n<0 and "Enable 3D mode." or "Trees changed: "..n
    end) end
    self:button("Reset age and snow",262,y,246,function() PZ3D.treeDebugReset();self.message="Preview reset." end);y=y+r
    self.targetY=y;y=y+r+6
    self.statsY=y;y=y+r*5
    self.messageY=y;self:setHeight(y+r+10)
    self:syncDate()
end
function Panel:days()
    if not self.month then return end
    local keep=self.day.selected;local m=self.month.selected;local yr=tonumber(self.year and self.year:getText()) or 1993
    local n=({31,28,31,30,31,30,31,31,30,31,30,31})[m]
    if m==2 and yr%4==0 and (yr%100~=0 or yr%400==0) then n=29 end
    self.day:clear();for i=1,n do self.day:addOption(tostring(i)) end;self.day.selected=math.min(keep,n)
end
function Panel:syncDate()
    local s=PZ3D.treeDebugState();self.year:setText(tostring(s.year));self.month.selected=s.month;self:days();self.day.selected=s.day
    local minutes=math.floor(s.time*60+.001)%1440;self.clock:setText(string.format("%02d:%02d",math.floor(minutes/60),minutes%60))
end
function Panel:update()
    ISPanel.update(self)
    if not available() then self:close();return end
    local now=getTimestampMs();if now<self.nextRefresh then return end;self.nextRefresh=now+250
    local ok,s=pcall(PZ3D.treeDebugState);if not ok then self.message=tostring(s);return end
    self.state=s;self.data={};for k,v in s.stats:gmatch("([%w]+)=([^%s]+)") do self.data[k]=v end
    self.radius:setEnabled(self.mode.selected==2)
end
function Panel:prerender()
    ISPanel.prerender(self)
    for _,l in ipairs(self.labels) do self:drawText(l.text,12,l.y,.85,.91,.9,1,UIFont.Small) end
    if not self.state then return end
    local s,d=self.state,self.data;local function num(k) return tonumber(d[k]) or 0 end
    local minutes=math.floor(s.time*60+.001)%1440
    self:drawText(string.format("%02d.%02d.%04d  %02d:%02d",s.day,s.month,s.year,math.floor(minutes/60),minutes%60),252,self.nowY,.8,.8,.8,1,UIFont.Small)
    self:drawText("Target: "..(s.target~="" and s.target or "-"),12,self.targetY,.8,.8,.8,1,UIFont.Small)
    local lines={
        "Visible / loaded: "..num("ezVisible").." / "..num("ezTrees").."    LOD: "..(d.ezLod or "-"),
        "Triangles: "..num("ezTriangles").."    Draws: "..num("ezDraws"),
        string.format("GPU geometry %.1f MiB | textures %.1f MiB",num("ezMeshGpuKB")/1024,num("ezTextureGpuKB")/1024),
        string.format("Java assets %.1f MiB | variants %d / %d",num("ezAssetHeapKB")/1024,num("ezVariants"),num("ezVariantLimit")),
        "Snow: "..math.floor(num("ezSnow")*100+.5).."% | "..(s.snow<0 and "weather" or "preview").." | transitioning: "..num("ezTransitioning")
    }
    if not s.active then lines[1]="3D inactive | last-frame data below" end
    for i,line in ipairs(lines) do self:drawText(line,12,self.statsY+(i-1)*self.rh,.75,.8,.8,1,UIFont.Small) end
    self:drawText(self.message or "",12,self.messageY,.95,.8,.45,1,UIFont.Small)
end
function Panel:close() self:removeFromUIManager();Panel.instance=nil end
function Panel.open()
    if not available() then return end
    if Panel.instance then Panel.instance:bringToTop();return end
    local p=Panel:new(math.max(0,getCore():getScreenWidth()-540),30,520,650)
    Panel.instance=p;p:initialise();p:addToUIManager();p:setAlwaysOnTop(true)
end
local original=ISDebugMenu.setupButtons
function ISDebugMenu:setupButtons()
    original(self)
    local info=self:addButtonInfo("pz3d | Trees",Panel.open,"MAIN")
    table.remove(self.buttons,#self.buttons)
    for i,b in ipairs(self.buttons) do if b.tab=="MAIN" and b.func==nil then table.insert(self.buttons,i,info);return end end
    table.insert(self.buttons,info)
end
