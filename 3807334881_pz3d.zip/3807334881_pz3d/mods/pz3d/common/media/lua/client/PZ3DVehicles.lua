require "Vehicles/ISUI/ISVehicleMenu"
require "ISUI/ISUIHandler"
require "ISUI/ISEmoteRadialMenu"
require "ISUI/ISLightSourceRadialMenu"

LuaEventManager.AddEvent("OnPZ3DVehicle")
LuaEventManager.AddEvent("OnPZ3DNativeKey")
local nativeHandlers, radialOwned, actionOwned

local function vehicleActions(player)
    local queue=ISTimedActionQueue.getTimedActionQueue(player)
    for _,action in ipairs(queue and queue.queue or {}) do
        if action.vehicle or action.vehicleA or action.vehicleB or action.part
            or (action.goal and type(action.goal[1]) == "string" and string.find(action.goal[1],"Vehicle")) then
            return true
        end
    end
    return false
end

local function visible(panel) return panel and panel:isReallyVisible() end
local function observe(player)
    if not player or not PZ3D or not PZ3D.active() or PZ3D.nativeControls and PZ3D.nativeControls() then return end
    actionOwned=vehicleActions(player)
    PZ3D.vehicleAction(actionOwned)
    local radial=getPlayerRadialMenu(player:getPlayerNum())
    if radialOwned and not visible(radial) then radialOwned=false end
    local seats=ISVehicleMenu.seatUI and ISVehicleMenu.seatUI[player:getPlayerNum()]
    local mechanics=getPlayerMechanicsUI(player:getPlayerNum())
    PZ3D.vehicleUi(visible(radial) or visible(seats) or visible(mechanics) or false)
end

Events.OnPZ3DVehicle.Add(function(player, kind, vehicle)
    if not player then return end
    if kind == "use" then
        if vehicleActions(player) then return end
         
         
        player:setBlockMovement(false)
        triggerEvent("OnUseVehicle",player,vehicle)
        observe(player)
    elseif kind == "press" then
        player:setBlockMovement(false)
        ISUIHandler.onKeyStartPressed(getCore():getKey("VehicleRadialMenu"))
        radialOwned=visible(getPlayerRadialMenu(player:getPlayerNum()))
        observe(player)
    elseif kind == "release" then
        ISUIHandler.onKeyPressed(getCore():getKey("VehicleRadialMenu"))
        radialOwned=visible(getPlayerRadialMenu(player:getPlayerNum()))
        observe(player)
    elseif kind == "cancel" then
        if radialOwned then getPlayerRadialMenu(player:getPlayerNum()):undisplay() end
        radialOwned=false
        PZ3D.vehicleUi(false)
    end
end)

Events.OnPZ3DNativeKey.Add(function(kind,key)
    if getCore():isKey("Toggle UI",key) and not getCore():isKey("VehicleRadialMenu",key) then
        if kind=="release" then ISUIHandler.onKeyPressed(key) end
    end
    if kind == "press" then
        ISEmoteRadialMenu.onKeyPressed(key)
        ISLightSourceRadialMenu.onKeyPressed(key)
        ISVehicleMenu.onKeyStartPressed(key)
    elseif kind == "hold" then
        ISEmoteRadialMenu.onKeyRepeat(key)
        ISLightSourceRadialMenu.onKeyRepeat(key)
    elseif kind == "release" then
        ISEmoteRadialMenu.onKeyReleased(key)
        ISLightSourceRadialMenu.onKeyReleased(key)
        ISVehicleMenu.onKeyPressed(key)
    elseif kind == "cancel" then
        local player=getPlayer()
        if player and player:getVehicle() and getCore():isKey("VehicleHorn",key) then ISVehicleMenu.onHornStop(player) end
    end
    observe(getPlayer())
end)

local nativeVehicleInput=false
local function customHandlers(custom)
    if custom and not nativeHandlers then
        Events.OnKeyStartPressed.Remove(ISUIHandler.onKeyStartPressed)
        Events.OnKeyPressed.Remove(ISUIHandler.onKeyPressed)
        Events.OnKeyStartPressed.Remove(ISEmoteRadialMenu.onKeyPressed)
        Events.OnKeyStartPressed.Remove(ISLightSourceRadialMenu.onKeyPressed)
        Events.OnKeyKeepPressed.Remove(ISEmoteRadialMenu.onKeyRepeat)
        Events.OnKeyKeepPressed.Remove(ISLightSourceRadialMenu.onKeyRepeat)
        Events.OnKeyPressed.Remove(ISEmoteRadialMenu.onKeyReleased)
        Events.OnKeyPressed.Remove(ISLightSourceRadialMenu.onKeyReleased)
        Events.OnKeyStartPressed.Remove(ISVehicleMenu.onKeyStartPressed)
        Events.OnKeyPressed.Remove(ISVehicleMenu.onKeyPressed)
        nativeHandlers=true
    elseif not custom and nativeHandlers then
        Events.OnKeyStartPressed.Add(ISUIHandler.onKeyStartPressed)
        Events.OnKeyPressed.Add(ISUIHandler.onKeyPressed)
        Events.OnKeyStartPressed.Add(ISEmoteRadialMenu.onKeyPressed)
        Events.OnKeyStartPressed.Add(ISLightSourceRadialMenu.onKeyPressed)
        Events.OnKeyKeepPressed.Add(ISEmoteRadialMenu.onKeyRepeat)
        Events.OnKeyKeepPressed.Add(ISLightSourceRadialMenu.onKeyRepeat)
        Events.OnKeyPressed.Add(ISEmoteRadialMenu.onKeyReleased)
        Events.OnKeyPressed.Add(ISLightSourceRadialMenu.onKeyReleased)
        Events.OnKeyStartPressed.Add(ISVehicleMenu.onKeyStartPressed)
        Events.OnKeyPressed.Add(ISVehicleMenu.onKeyPressed)
        nativeHandlers=false
    end
end

Events.OnPZ3DVehicleInput.Add(function(native)
    nativeVehicleInput=native and PZ3D.active()
    customHandlers(PZ3D.active() and not nativeVehicleInput and not (PZ3D.nativeControls and PZ3D.nativeControls()))
end)
Events.OnPZ3DMode.Add(function(player,kind)
    if PZ3D.nativeControls and PZ3D.nativeControls() then customHandlers(false);return end
    if kind=="perspective" then kind="enter" end
    if kind == "enter" then
        nativeVehicleInput=false
        customHandlers(true)
    elseif kind == "exit" then
        if radialOwned then getPlayerRadialMenu(player:getPlayerNum()):undisplay() end
        customHandlers(false)
        nativeVehicleInput=false;radialOwned=false;actionOwned=false
        PZ3D.vehicleAction(false);PZ3D.vehicleUi(false)
    end
end)
Events.OnTick.Add(function() observe(getPlayer()) end)
