 
 
return {
    {
        id = "release-0.4.1",
        translations = {
            EN = {
                title = "0.4.1",
                text = [[Fixed

- Garbled Russian text in the Assets Manager.]],
            },
        },
    },

    {
        id = "release-0.4.0",
        translations = {
            EN = {
                title = "0.4.0",
                text = [[Added

- Top Down camera.
- Assets Manager for browsing, previewing and choosing model replacements.
- Adjustable first-person field of view.

Changed

- Optimization, a lot.
- View mode selector.
- Vanilla day/night cycles.

Fixed

- First-person movement getting stuck in combat-speed strafing.
- Zombie animations stopping outside the isometric view.
- Sunlit vehicles appearing too dark.]],
            },
        },
    },


    {
        id = "release-0.3.0",
        translations = {
            EN = {
                title = "0.3.0",
                text = [[Changed

- Updated for Project Zomboid 42.21.0.]],
            },
        },
    },

    {
        id = "release-0.2.2",
        translations = {
            EN = {
                title = "0.2.2",
                text = [[Changed

- The first/third-person key restores your last selected view when entering 3D from isometric mode.

Fixed

- You can now walk while using the inventory in first-person and third-person views.
- Third-person flashlights now follow the character's facing direction and hand position.
- Restored vanilla lamp, flashlight and room-light colors (test it please and report) and distance.]],
            },
        },
    },

    {
        id = "release-0.2.1",
        translations = {
            EN = {
                title = "0.2.1",
                text = [[Fixed

- You can now walk while using the inventory in first-person and third-person views]],
            },
        },
    },
    {
        id = "release-0.2.0",
        translations = {
            EN = {
                title = "0.2.0",
                text = [[Added

- First-person and third-person camera modes, selectable through the ISO/3D sidebar button.
- Firearm ADS: tap RMB to enter or leave sights.
- Procedural trees with seed-based variations, seasonal foliage and snow-covered branches.
- Ground snow with partial coverage and thawing.
- Rebuilt extensions manager.
- This main-menu news journal.

Changed

- Movement, climbing, combat and third-person vehicle controls now follow vanilla mechanics.
- Improved camera positioning, close zoom and first-person views.
- Native object interactions and context menus (LMB, RMB) in the Tab overlay.
- Clicked objects are highlighted.
- Smoother tree growth and LOD transitions.
- Optimized rendering, shadows and loading.

Fixed

- 3D startup and shader issues on affected AMD and Linux drivers.
- A crash when aiming firearms.
- Automatic fire, third-person aiming and bullet tracer alignment.
- Repeated shoves from a single key press.
- Sprint bindings and mod key rebinding.
- Grass rendering, spring foliage and snow seams.
- Flickering TV and radio captions.
- Missing Core models in the extensions manager.

Removed

- Interaction prompts.
- Custom vehicle mirror reflections (TEMPORARILY!)]],
            },
        },
    },
}
