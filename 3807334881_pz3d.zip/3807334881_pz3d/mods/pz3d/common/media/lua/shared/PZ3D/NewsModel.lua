local Model = {}

function Model.validate(entries)
    local ids = {}
    for _, entry in ipairs(entries) do
        assert(type(entry.id) == "string" and entry.id ~= "" and not ids[entry.id], "News IDs must be unique nonempty strings")
        ids[entry.id] = true
        assert(type(entry.translations) == "table" and entry.translations.EN, "News requires an English translation: " .. entry.id)
        for _, translation in pairs(entry.translations) do
            assert(type(translation.title) == "string" and translation.title ~= "" and type(translation.text) == "string" and translation.text ~= "", "News title/text missing: " .. entry.id)
        end
    end
end

function Model.new(entries, store)
    Model.validate(entries)
    local self = { entries = entries, store = store, unreadCount = 0 }
    setmetatable(self, { __index = Model })
     
    if #entries > 0 and not store.newsInitialized() then
        for i = 2, #entries do store.newsMarkRead(entries[i].id) end
        self.saved = store.newsSave()
    end
    for _, entry in ipairs(entries) do if self:unread(entry) then self.unreadCount = self.unreadCount + 1 end end
    return self
end

function Model:translation(entry, language)
    return entry.translations[language] or entry.translations.EN
end

function Model:unread(entry) return not self.store.newsRead(entry.id) end
function Model:hasUnread() return self.unreadCount > 0 end
function Model:read(entry)
    if self:unread(entry) then self.unreadCount = self.unreadCount - 1 end
    self.store.newsMarkRead(entry.id)
    self.saved = self.store.newsSave()
end
function Model:readAll()
    for _, entry in ipairs(self.entries) do self.store.newsMarkRead(entry.id) end
    self.unreadCount = 0
    self.saved = self.store.newsSave()
end
return Model
